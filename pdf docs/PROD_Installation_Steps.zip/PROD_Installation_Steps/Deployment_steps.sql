
1.Create directory PLSQL_P3 - mkdir -p $HOME/xxjars/history/PLSQL_P3/

2.Create blank temp.sql  - $HOME/xxjars/history/PLSQL_P3/temp.sql

3.Copy deploy-Script-plsql_P3.sh under xxjars from folder PLSQL Deployment.

4.Copy other files from PLSQL Deployment to @/net/jdnfs/vol/vol6/oracleinstall/scripts/

5.Copy all files from webservices deployment folder to @$HOME/scripts/ 