select class_id from fnd_irep_classes where class_name like '%XXRCSS%' order by class_id desc;
quit;
/
