#!/bin/ksh 
APPS_PASS=$1

. /oraebs/applmgr/jdf1227/EBSapps.env run

#Drop Old WebServices
OUTPUT=`sqlplus -s APPS/$APPS_PASS @$HOME/scripts/rcssGetSOAIds.sql`
ID1=`echo $OUTPUT | cut -d ' ' -f3`
ID2=`echo $OUTPUT | cut -d ' ' -f4`

echo "Dropping Old Services"
if [[ -n $ID1 ]]; then
	sqlplus -s APPS/$APPS_PASS @$HOME/scripts/RcssDeleteFromIRep.sql $ID1
fi
if [[ -n $ID2 ]]; then
	sqlplus -s APPS/$APPS_PASS @$HOME/scripts/RcssDeleteFromIRep.sql $ID2
fi
sqlplus -s APPS/$APPS_PASS @$HOME/scripts/DropGeneratedTypesAndPackagesrcss.sql

echo "Creating New IDLT Files"
#Move xxmobl_api_pk.pls to idlt_soafiles directory and updated to database

#Remove Old Files
cd $XXJDFL_TOP/bin
rm XXRCSS_WEBSERVICES.pls
rm XXRCSS_WEBSERVICES_pls.ildt
rm *.log

#servers stop
#cd $ADMIN_SCRIPTS_HOME
#./admanagedsrvctl.sh stop oafm_server1 welcome123

#./admanagedsrvctl.sh start oafm_server1 welcome123

cd $XXJDFL_TOP/bin
#Copy New File
cp $HOME/xxjars/PLSQL_P3/PLSQL/XXRCSS_WEBSERVICES.sql XXRCSS_WEBSERVICES.pls

#Create and Upload To Database
$HOME/scripts/rcsscreateIDLT.sh $APPS_PASS

CHECK_LOG=`grep successfully *.log`
if [[ $CHECK_LOG != "Concurrent request completed successfully" ]]; then
	exit 1
fi


