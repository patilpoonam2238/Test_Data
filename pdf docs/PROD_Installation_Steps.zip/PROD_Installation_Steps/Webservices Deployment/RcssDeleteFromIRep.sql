set serveroutput on;

declare
        key_id NUMBER(15) := '&1';
        assoc_key_id NUMBER(15);
        stable VARCHAR2(16);
        filename VARCHAR2(36);
        fileproduct VARCHAR2(8);
        fileversion VARCHAR2(150);
        ildtfilename VARCHAR2(150);
begin
        --fetch source table
        select src_table
        into stable
        from FND_IREP_ALL_INTERFACES
        where class_id = key_id;


        if (stable = 'FND_IREP_CLASSES') then
                -- find file name and update history table

                select source_file_name, source_file_product, source_file_version
                into filename, fileproduct, fileversion
                from fnd_irep_classes
                where class_id = key_id;

                ildtfilename  := replace(filename,'.','_');
                ildtfilename  := ildtfilename || '.ildt';

                begin
                        update fnd_irep_deferred_load_files
                        set load_status = 'N'
                        where file_name = ildtfilename
                        and fileproduct = file_product
                        and fileversion = file_version;
                exception
                when others then
                        dbms_output.put_line('Error: History table does not have this entry.');
                end;


                -- remove class subentities (except methods)

                Delete from FND_IREP_CLASS_DATASOURCES
                where CLASS_ID = key_id;


                Delete from FND_IREP_CLASS_PARENT_ASSIGNS
                where class_name in
                        (select class_name
                        from fnd_irep_classes
                        where class_id = key_id);

                Delete from FND_LOOKUP_ASSIGNMENTS
                where obj_name = 'FND_IREP_CLASSES'
                  and INSTANCE_PK1_VALUE = to_char(key_id);

                Delete from FND_CHILD_ANNOTATIONS
                where parent_id = key_id
                  and parent_flag = 'C';

                Delete from FND_IREP_USES_TABLES
                where CLASS_ID = key_id;

                Delete from FND_IREP_USES_MAPS
                where CLASS_ID = key_id;

                dbms_output.put_line('Class Sub-Entities Removed');

                -- remove method subentities
                Delete from FND_LOOKUP_ASSIGNMENTS
                where obj_name = 'FND_IREP_FUNCTION_FLAVORS'
                  and INSTANCE_PK1_VALUE in
                        (select function_id
                           from FND_FORM_FUNCTIONS
                          where irep_class_id = key_id);

                Delete from FND_CHILD_ANNOTATIONS
                where parent_flag = 'F'
                  and parent_id in
                        (select function_id
                           from FND_FORM_FUNCTIONS
                          where irep_class_id = key_id);

                Delete from FND_PARAMETERS
                where function_id in
                        (select function_id
                           from FND_FORM_FUNCTIONS
                          where irep_class_id = key_id);

                dbms_output.put_line('Function Sub-Entities Removed');


                -- ### remove derived entries ###
                begin
                        --fetch derived entry
                        select class_id
                        into assoc_key_id
                        from FND_IREP_ALL_INTERFACES
                        where assoc_class_id  = key_id;

                        dbms_output.put_line('Derived Entry : '|| assoc_key_id);

                        -- remove flavors
                        Delete from FND_IREP_FUNCTION_FLAVORS
                        where FUNCTION_ID in
                                (select function_id
                                from FND_FORM_FUNCTIONS
                                where irep_class_id = assoc_key_id);

                        dbms_output.put_line('Derived Function Flavors Removed');

                        --remove functions
                        Delete from FND_FORM_FUNCTIONS_TL
                        where function_id in
                                (select function_id
                                from fnd_form_functions
                                where irep_class_id = assoc_key_id);

                        Delete from FND_FORM_FUNCTIONS
                        where irep_class_id  = assoc_key_id;

                        dbms_output.put_line('Derived Functions Removed');

                        -- remove classes
                        Delete from FND_IREP_CLASSES_TL
                        where class_id = assoc_key_id;

                        Delete from FND_IREP_CLASSES
                        where class_id = assoc_key_id;

                        dbms_output.put_line('Derived Classes Removed');
                exception
                when others then
                        dbms_output.put_line('Derived Entries Not Present.');
                end;


                -- ### remove basic entries ###

                -- remove flavors
                Delete from FND_IREP_FUNCTION_FLAVORS
                where FUNCTION_ID in
                        (select function_id
                        from FND_FORM_FUNCTIONS
                        where irep_class_id = key_id);

                dbms_output.put_line('Function Flavors Removed');

                --remove functions
                Delete from FND_FORM_FUNCTIONS_TL
                where function_id in
                        (select function_id
                        from fnd_form_functions
                        where irep_class_id = key_id);

                Delete from FND_FORM_FUNCTIONS
                where irep_class_id  = key_id;

                dbms_output.put_line('Functions Removed');

                -- remove classes
                Delete from FND_IREP_CLASSES_TL
                where class_id = key_id;

                Delete from FND_IREP_CLASSES
                where class_id = key_id;

                dbms_output.put_line('Classes Removed');

                dbms_output.put_line('Deletion completed for all entries corresponding to Class Id : '|| key_id);

        else
                -- remove object subentities
                Delete from FND_OBJECT_KEY_SETS
                where object_id = key_id;

                Delete from FND_LOOKUP_ASSIGNMENTS
                where obj_name = 'FND_OBJECTS'
                and INSTANCE_PK1_VALUE = to_char(key_id);

                Delete from FND_CHILD_ANNOTATIONS
                where parent_id = key_id
                and parent_flag = 'O';

                Delete from FND_OBJECT_TYPE_MEMBERS
                where object_id = key_id;

                dbms_output.put_line('Object Sub-Entities Removed');

                -- remove objects
                Delete from FND_OBJECTS_TL
                where object_id = key_id;

                Delete from FND_OBJECTS
                where object_id  = key_id;

                dbms_output.put_line('Objects Removed');

                dbms_output.put_line('Deletion completed for all entries corresponding to object Id : '|| key_id);

        end if;
commit;
exception

 when others then
   dbms_output.put_line(SQLERRM);
end;

/
commit;
exit;

