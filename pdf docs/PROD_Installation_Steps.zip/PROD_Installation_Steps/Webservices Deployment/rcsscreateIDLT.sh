#!/bin/sh
# NOTE:  To redeploy a service, update the version number
APPS_PASS=$1
perl $FND_TOP/bin/irep_parser.pl -g -v -username=sysadmin XXJDFL:patch/115/sql:XXRCSS_WEBSERVICES.pls:12.0=XXRCSS_WEBSERVICES.pls 
FNDLOAD apps/$APPS_PASS 0 Y UPLOAD $FND_TOP/patch/115/import/wfirep.lct XXRCSS_WEBSERVICES_pls.ildt
