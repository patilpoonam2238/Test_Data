BEGIN

  --FOR y IN (SELECT object_name from dba_objects where object_name like 'ISG_XXRCSS%' and object_type = 'PACKAGE') LOOP
  --  EXECUTE IMMEDIATE 'drop package ' || y.object_name;
  --END LOOP; 
  
  FOR x IN (SELECT object_name from dba_objects where (object_name like 'XXRCSS%' or object_name like 'XXRCSS%') and object_type = 'TYPE') LOOP
    EXECUTE IMMEDIATE 'drop type ' || x.object_name || ' force';
  END LOOP;
                      
                      
END;
/
commit;
exit;
