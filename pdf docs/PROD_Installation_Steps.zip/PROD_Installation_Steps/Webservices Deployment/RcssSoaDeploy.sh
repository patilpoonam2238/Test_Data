#!/bin/ksh 
. /oraebs/applmgr/jdf1227/EBSapps.env run
cd $JAVA_TOP/oracle/apps/fnd/isg/ant
ls
ant -f isgDesigner.xml -DdbcFile=$FND_SECURE/JDFINTLP.dbc -Dactions="deploy" -DserviceType="REST" -DirepNames="XXRCSS_WEBSERVICES" -Dverbose=ON -Dalias="XXRCSS"
