/*========================================================================
 |  Compiles invalid objects for EBS 			                 |
 |                     Script is used in Junkins                         |
 |                      Version 1.1.0 ---Updated by Afaq  
                                2.0  ----Updated by meetali             |
=========================================================================*/
rem
rem Sql script that:
rem Compiles Invalid Objects in current edition for EBS
rem
rem Syntax:  @compile_invalid_obj_New.sql
declare
cursor invalid_objects is
  select owner,object_name, object_type
  from dba_objects
  where object_type in ('PACKAGE', 'PACKAGE BODY','VIEW','PROCEDURE','FUNCTION')
  and status = 'INVALID'
 and trunc(last_ddl_time) = trunc(SYSDATE)
  and owner not in ('SYS','OLAPSYS','SQLTXADMIN','OWAPUB')
  and (object_name like 'XXRCSS%');
begin
for rec in invalid_objects
    loop
        begin
        if(rec.object_type = 'PACKAGE BODY') then
        dbms_output.put_line('package body  '||'ALTER PACKAGE BODY '||REC.OWNER||'.' || rec.object_name || ' COMPILE BODY');
          EXECUTE IMMEDIATE 'ALTER PACKAGE BODY '||'ALTER PACKAGE BODY '||REC.OWNER||'.' || rec.object_name || ' COMPILE BODY';
        else
         dbms_output.put_line('other objects  '||'ALTER '||REC.object_type||' '||REC.OWNER|| '.' || rec.object_name || ' COMPILE');
          EXECUTE IMMEDIATE 'ALTER '||REC.object_type||' '||REC.OWNER|| '.' || rec.object_name || ' COMPILE';
        end if;
        exception
          when others then
            null;
        end;
    end loop;
--commit;
end;
/
quit;
