#!/bin/ksh
PASSWORD=$1;
USER=applmgr;
#. /oraebs/appldev/apps_st/appl/APPSJDFINTD3_ebsdev2.env
. /oraebs/$USER/jdf1227/EBSapps.env run
LOG=/oraebs/$USER/xxjars/log.log
cat /dev/null > $LOG

if [[ -z $PASSWORD ]]; then
   echo ""
   echo "APPS Password Not Entered"
   echo "PLSQL Code Not Applied"
   echo ""
   exit 1
fi

TEMP=`echo exit | sqlplus -s APPS/$PASSWORD @/net/jdnfs/vol/vol6/oracleinstall/scripts/invalid_objects_count_P3.sql`
CURRENT_INVALID_OBJECTS=`echo $TEMP | cut -d ' ' -f3`

#unzip plsql files
cp plsqls_P3.zip PLSQL_P3
cd PLSQL_P3
unzip -o plsqls_P3.zip
cd PLSQL

historypath=$HOME/xxjars/history/PLSQL_P3/


#loop through files
for file in `ls`
do
  #check file with history to see if it is different
  historyfile=`echo $historypath\$file`
  diff $file $historyfile > $LOG 2>&1
  if [[ $? -ne 0 ]]; then
     #different so copy to history folder and install to database
     echo "deploying"
     echo $file
     echo $historyfile
     install=1

     extension=$(echo ${file}|awk -F\. '{print $2}')
                        if [ ${extension} == "sql" ]; then
                        echo ${extension}
                        echo "File Before Append......................"
                        echo $file
                        historypath1=`echo $historypath\temp.sql`
                        echo $file
                        cat /dev/null > ${historypath1}
                         (cat ${file} ; echo " / ") >> ${historypath1}
                        #cat ${file} >> ${historypath1}
                        cp $file $historypath
                        #echo "\n/" >> $historypath1
                        echo $historypath1

                SQL_OUTPUT=`sqlplus apps/$PASSWORD <<-EOF
                                set serveroutput on;
                                set define off;
                                whenever oserror exit 77;
                                whenever sqlerror exit 99;
                                @$historypath1;
                                SHOW ERRORS;
                                exit;
                                EOF`

                        fi

                        echo $?
      case $? in
                                 0) echo "\n\nALL SUCCESSFUL!";;
                                99) echo "ERROR! SQL*Plus failed..."; exit 1;;
                                77) echo "ERROR! OS failure..."; exit 2;;
                                57) echo "ERROR! SQL*Plus failed..."; exit 3;;
                                17) echo "ERROR! SQL*Plus failed..."; exit 4;;
                                 *) echo "Warning! Unexplained exit code: "$?;;
                        esac
  fi

done

#cat /dev/null > ${historypath1}
TEMP=`echo exit | sqlplus -s APPS/$PASSWORD @/net/jdnfs/vol/vol6/oracleinstall/scripts/invalid_objects_count_P3.sql`
INVALID_OBJECTS=`echo $TEMP | cut -d ' ' -f3`

echo "COMPILING INVALID OBJECTS"
echo exit | sqlplus -s APPS/$PASSWORD @/net/jdnfs/vol/vol6/oracleinstall/scripts/compile_invalid_obj_New_P3.sql
echo exit | sqlplus -s APPS/$PASSWORD @/net/jdnfs/vol/vol6/oracleinstall/scripts/compile_invalid_obj_New_P3.sql
echo exit | sqlplus -s APPS/$PASSWORD @/net/jdnfs/vol/vol6/oracleinstall/scripts/compile_invalid_obj_New_P3.sql
echo exit | sqlplus -s APPS/$PASSWORD @/net/jdnfs/vol/vol6/oracleinstall/scripts/compile_invalid_obj_New_P3.sql

#echo "Current Invalid Objects" >> $FAILED_FILES_LOG
TEMP=`echo exit | sqlplus -s APPS/$PASSWORD @/net/jdnfs/vol/vol6/oracleinstall/scripts/invalid_objects_P3.sql`
#echo $TEMP >> $FAILED_FILES_LOG

if [[ -s $FAILED_FILES_LOG ]]; then
  mailx -s "PLSQL Files Failed on Prod Environment" GlobalITFinancialOLFMSupport@JohnDeere.com < $FAILED_FILES_LOG
fi

exit 0
