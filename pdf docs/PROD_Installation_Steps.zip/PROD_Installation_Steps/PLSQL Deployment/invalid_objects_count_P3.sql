select count(object_name) invalid_objects 
from dba_objects 
where object_type in ('PACKAGE', 'PACKAGE BODY','VIEW','PROCEDURE','FUNCTION') 
and status = 'INVALID' 
and (object_name like 'XXRCSS%');
quit;
/
