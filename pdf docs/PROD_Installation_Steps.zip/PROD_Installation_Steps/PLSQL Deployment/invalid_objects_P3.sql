select object_name, object_type
from dba_objects 
where object_type in ('PACKAGE', 'PACKAGE BODY','VIEW','PROCEDURE','FUNCTION') 
and status = 'INVALID' 
and object_name like 'XXRCSS%';
quit;
/
