create or replace PACKAGE BODY XXRCSS_UTIL_PKG AS

FUNCTION get_party_details(p_contract_number IN okc_k_headers_all_b.contract_number%TYPE) RETURN NUMBER IS 
v_party_id  hz_parties.party_id%TYPE;
BEGIN
SELECT hp.party_id 
  INTO v_party_id 
  FROM  okc_k_headers_all_b chr
        ,hz_parties hp
        ,hz_cust_accounts hca
  WHERE chr.cust_acct_id=hca.cust_account_id
  AND   hca.party_id = hp.party_id 
  AND   chr.contract_number = p_contract_number
  AND   hca.status ='A'
  AND   hp.status = 'A' ; 

return v_party_id;
EXCEPTION
WHEN NO_DATA_FOUND THEN 
DBMS_output.put_line('Party details for mentioned contract not found.');
return v_party_id;
END get_party_details;


FUNCTION get_org_details(p_contract_number IN okc_k_headers_all_b.contract_number%TYPE) RETURN NUMBER IS 
v_org_id  hr_operating_units.organization_id%TYPE;
BEGIN
  SELECT hou.organization_id 
  INTO v_org_id 
  FROM  okc_k_headers_all_b chr
        ,hr_operating_units hou
  WHERE chr.authoring_org_id=hou.organization_id
  AND   chr.contract_number = p_contract_number;

return v_org_id;
EXCEPTION
WHEN NO_DATA_FOUND THEN 
dbms_output.put_line('No Org details found '||SQLERRM);
return v_org_id;
END get_org_details;


/*to validate customer entered having at least one contract in booked state*/
PROCEDURE validate_contract(p_contract_number   IN okc_k_headers_all_b.contract_number%TYPE
						   ,p_cust_acct_id      IN okc_k_headers_all_b.cust_acct_id%TYPE
						   ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
						   ,l_contract_num     OUT NUMBER) 
IS 
v_contract_num  okc_k_headers_all_b.contract_number%TYPE;
BEGIN

  SELECT chr.contract_number 
  INTO v_contract_num 
  FROM  okc_k_headers_all_b chr
        ,hz_cust_accounts_all hca
  WHERE  chr.cust_acct_id = hca.cust_account_id
  AND chr.contract_number = NVL(p_contract_number,chr.contract_number)
  AND   chr.cust_acct_id  = NVL(p_cust_acct_id,chr.cust_acct_id)
  AND   hca.account_number = NVL(p_cust_acct_number,hca.account_number)
  AND   chr.sts_code ='BOOKED'
  AND   hca.status = 'A'
  AND rownum =1;

l_contract_num:= v_contract_num;
EXCEPTION
WHEN NO_DATA_FOUND THEN 
DBMS_output.put_line('Combination of parameters entered is Invalid please enter correct parameters.');
l_contract_num:= v_contract_num;
END validate_contract;


PROCEDURE validate_contract(p_contract_number   IN okc_k_headers_all_b.contract_number%TYPE
						   ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
						   ,l_contract_num     OUT NUMBER)
IS
v_contract_num  okc_k_headers_all_b.contract_number%TYPE;
BEGIN

  SELECT chr.contract_number
  INTO v_contract_num
  FROM  okc_k_headers_all_b chr
        ,hz_cust_accounts_all hca
  WHERE  chr.cust_acct_id =hca.cust_account_id
  AND chr.contract_number = NVL(p_contract_number,chr.contract_number)
  AND   hca.account_number = NVL(p_cust_acct_number,hca.account_number)
  AND   chr.sts_code ='BOOKED'
  AND   hca.status = 'A'
  AND rownum =1;

l_contract_num:= v_contract_num;
EXCEPTION
WHEN NO_DATA_FOUND THEN
DBMS_output.put_line('Combination of parameters entered is Invalid please enter correct parameters.');
l_contract_num:= v_contract_num;
END validate_contract;

END XXRCSS_UTIL_PKG;
/