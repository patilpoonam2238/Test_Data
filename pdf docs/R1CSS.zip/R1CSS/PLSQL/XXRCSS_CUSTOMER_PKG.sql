create or replace PACKAGE XXRCSS_CUSTOMER_PKG AS 

 PROCEDURE main_cust_info
(p_contract_number     IN okc_k_headers_all_b.contract_number%TYPE
  ,p_cust_acct_id      IN okc_k_headers_all_b.cust_acct_id%TYPE
  ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_cust_info    	  OUT nocopy XXRCSS_TYPES_PK.cust_tbl_type
  ,x_address_loc      OUT nocopy XXRCSS_TYPES_PK.loc_tbl_type
  ,x_alt_emails       OUT nocopy XXRCSS_TYPES_PK.email_tbl_type
  ,x_alt_phone        OUT nocopy XXRCSS_TYPES_PK.phone_tbl_type    
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
);

END XXRCSS_CUSTOMER_PKG;
/