create or replace PACKAGE XXRCSS_ASSET_PKG AS 

 PROCEDURE main_asset_info
( p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_asset_info    	  OUT nocopy XXRCSS_TYPES_PK.asset_tbl_type    
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
);

END XXRCSS_ASSET_PKG;
/