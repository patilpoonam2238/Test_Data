create or replace PACKAGE  XXRCSS_TYPES_PK AS
TYPE loc_rec_type IS RECORD
     (
     x_ADDRESS1         hz_locations.ADDRESS1%tYPE
    ,x_ADDRESS2         hz_locations.ADDRESS2%tYPE
    ,x_address3         hz_locations.address3%tYPE
    ,x_address4         hz_locations.address4%tYPE
    ,x_city             hz_locations.city%tYPE
    ,x_postal_code      hz_locations.postal_code%tYPE
    ,x_state            hz_locations.state%tYPE
    ,x_country_code     hz_locations.country%tYPE
    ,x_country          FND_TERRITORIES_TL.territory_short_name%tYPE
    ,x_site_use_code    HZ_CUST_SITE_USES_ALL.site_use_code%TYPE
    ,x_primary          HZ_CUST_SITE_USES_ALL.primary_flag%TYPE
	 );


TYPE cust_rec_type IS RECORD
     (	 
	 x_party_name          		hz_parties.party_name%TYPE
  ,x_party_type          		hz_parties.party_type%TYPE
  ,x_org_name            		hr_operating_units.name%TYPE
  ,x_party_id            		hz_parties.party_id%TYPE
  ,x_cust_acct_num              hz_cust_accounts_all.account_number%TYPE
  ,x_party_unique_id     		hz_parties.jgzz_fiscal_code%TYPE
  ,x_party_first_name    		hz_parties.person_first_name%TYPE
  ,x_party_last_name     		hz_parties.person_last_name%TYPE 
  ,x_party_middle_name   		hz_parties.person_middle_name%TYPE
  ,x_party_maiden_name   		hz_parties.person_previous_last_name%TYPE
  ,x_alias_name                 hz_parties.known_as%TYPE
  ,x_party_primary_phone_number hz_parties.primary_phone_number%TYPE
  ,x_party_email_address        hz_parties.email_address%TYPE
  ,x_contact_first_name      	hz_parties.person_first_name%TYPE
  ,x_contact_last_name       	hz_parties.person_last_name%TYPE 
  ,x_contact_middle_name     	hz_parties.person_middle_name%TYPE
  ,x_contact_maiden_name   		hz_parties.person_previous_last_name%TYPE
  ,x_Date_of_birth           	hz_person_profiles.date_of_birth%TYPE
  ,x_contact_unique_id          hz_parties.jgzz_fiscal_code%TYPE
  ,x_contact_primary_phone_number    hz_parties.primary_phone_number%TYPE
  ,x_contact_email_address       hz_parties.email_address%TYPE 
  );

  TYPE email_rec_type IS RECORD
     (
      x_email_address     HZ_CONTACT_POINTS.email_address%TYPE
     ,x_email_type        HZ_CONTACT_POINTS.primary_flag%TYPE
     ,x_email_format      HZ_CONTACT_POINTS.email_format%TYPE
     ,x_cont_purpose      HZ_CONTACT_POINTS.contact_point_purpose%TYPE
	 );


  TYPE phone_rec_type IS RECORD
     (
      x_phone_line_type        HZ_CONTACT_POINTS.phone_line_type%TYPE
     ,x_phone_area_code        HZ_CONTACT_POINTS.phone_area_code%TYPE
     ,x_phone_country_code     HZ_CONTACT_POINTS.phone_country_code%TYPE
     ,x_phone_number           HZ_CONTACT_POINTS.phone_number%TYPE
     ,x_phone_extension        HZ_CONTACT_POINTS.phone_extension%TYPE
     ,x_cont_purpose           HZ_CONTACT_POINTS.contact_point_purpose%TYPE
     ,x_phone_type             HZ_CONTACT_POINTS.primary_flag%TYPE
	 );

	  TYPE asset_rec_type IS RECORD
     (
	  x_contract_number        OKC_K_HEADERS_ALL_B.contract_number%TYPE
      ,x_model_number          okl_k_lines.model_number%TYPE
     ,x_description            MTL_SYSTEM_ITEMS_B.description%TYPE
     ,x_chasis_number          okl_txl_itm_insts.serial_number%TYPE
     ,x_registration_number    OKC_RULES_B.rule_information4%TYPE
     ,x_engine_number          OKL_K_LINES.attribute3%TYPE
     ,x_manufacturer_name      OKL_K_LINES.manufacturer_name%TYPE
     ,x_asset_number           OKC_K_LINES_TL.name%TYPE
	 );

    TYPE contract_rec_type IS RECORD
     (
	  x_asset_number                 OKC_K_LINES_TL.name%TYPE
     ,x_payment_frequency           FND_LOOKUPS.meaning%TYPE
	 );

TYPE contract_tbl_type IS TABLE OF contract_rec_type;

	  TYPE contract_hdr_rec_type IS RECORD
     (
	  x_contract_number        		OKC_K_HEADERS_ALL_B.contract_number%TYPE
	  ,x_contract_desc               okc_k_headers_tl.short_description%TYPE
      ,x_loan_start_date         	OKC_K_HEADERS_ALL_B.start_date%TYPE
      ,x_loan_end_date          		OKC_K_HEADERS_ALL_B.end_date%TYPE
	  ,x_contract_tenure              okl_k_headers.term_duration%TYPE
	  ,x_loan_financed_amount         okl_txl_ap_inv_lns_all_b.amount%TYPE
      ,x_payment_method    			 AR_RECEIPT_METHODS.name%TYPE
      ,x_contract_interest_rate       okl_k_headers.attribute2%TYPE
	  ,x_product                     okl_products.name%TYPE
	  ,x_book_classification          fnd_lookup_values.meaning%TYPE
	  ,x_payment_frequency            FND_LOOKUPS.meaning%TYPE
	  ,x_late_policy_name			 okl_late_policies_tl.NAME%TYPE
	 );
	 
	/* TYPE insPolicyRecType IS RECORD
     (
	   x_policy_number		    okl_ins_policies_b.policy_number%TYPE
	 , x_date_to                  okl_ins_policies_b.date_to%TYPE
	 , x_date_from                okl_ins_policies_b.date_from%TYPE
	 , x_covered_amount           okl_ins_policies_b.covered_amount%TYPE
     , x_currency_code            okl_ins_policies_b.currency_code%TYPE
     , x_status                   VARCHAR2(15)
     , x_ipy_type                 okl_ins_policies_b.ipy_type%TYPE
     , x_insurance_type           fnd_lookups.meaning%TYPE
     , x_ins_provider_company     hz_parties.party_name%TYPE
     , ins_provider_address       VARCHAR2(1300)
	 );
	 	 
TYPE insPolicyTblType IS TABLE OF insPolicyRecType;*/

	TYPE contract_main_rec_type IS RECORD
     (
	 x_contract_hdr_dtl        contract_hdr_rec_type
	 ,x_contract_asset_dtl      contract_tbl_type
	-- ,x_insPolicyTblType        insPolicyTblType
	 );
	 
	
 TYPE latePolicyRecType IS RECORD
     (
	   x_late_policy_name					okl_late_policies_tl.NAME%TYPE
	 , x_late_policy_type_code              okl_late_policies_b.LATE_POLICY_TYPE_CODE%TYPE
	 , x_late_int_allowed_yn                okl_late_policies_b.LATE_INT_ALLOWED_YN%TYPE
	 , x_late_int_fixed_yn                  okl_late_policies_b.LATE_INT_FIXED_YN%TYPE
     , x_late_int_rate                      okl_late_policies_b.LATE_INT_RATE%TYPE
     , x_adder_rate                         okl_late_policies_b.ADDER_RATE%TYPE
     , x_late_int_grace_period              okl_late_policies_b.LATE_INT_GRACE_PERIOD%TYPE
     , x_late_int_minimum_balance           okl_late_policies_b.LATE_INT_MINIMUM_BALANCE%TYPE
     , x_minimum_late_interest              okl_late_policies_b.MINIMUM_LATE_INTEREST%TYPE
     , x_maximum_late_interest              okl_late_policies_b.MAXIMUM_LATE_INTEREST%TYPE
     , x_index_rate                           OKL_INDEX_VALUES.value%TYPE
     , x_days_in_year                       okl_late_policies_b.DAYS_IN_YEAR%TYPE
	 , x_bill_min_interest_yn               okl_late_policies_b.BILL_MIN_INTEREST_YN%TYPE
	 , x_datetime_valid                     OKL_INDEX_VALUES.DATETIME_VALID%TYPE
	 , x_datetime_invalid	                OKL_INDEX_VALUES.DATETIME_INVALID%TYPE
	 );
	 	 
TYPE latePolicyTblType IS TABLE OF latePolicyRecType;
	

TYPE cust_tbl_type IS TABLE OF cust_rec_type INDEX BY BINARY_INTEGER;

TYPE loc_tbl_type IS TABLE OF loc_rec_type;

TYPE phone_tbl_type IS TABLE OF phone_rec_type;

TYPE email_tbl_type IS TABLE OF email_rec_type;

TYPE asset_tbl_type IS TABLE OF asset_rec_type;

TYPE contract_main_tbl_type IS TABLE OF contract_main_rec_type;


---------------For Contract Invoice Service -------------------------
 TYPE contract_num_rec_type IS RECORD
     (
	  x_contract_number        		OKC_K_HEADERS_ALL_B.contract_number%TYPE
	 );
	 
	 TYPE payment_sch_rec_type IS RECORD
     (
	     x_stream						okl_strm_type_b.stream_type_purpose%TYPE
		 ,x_stream_amount          okl_strm_elements.amount%TYPE
		 ,x_stream_date            okl_strm_elements.stream_element_date%TYPE
		,x_billed_date                  okl_strm_elements.date_billed%TYPE
		,x_invoice_amount           	ra_customer_trx_lines_all.amount_due_original%TYPE
		,x_amount_due_remaining			ra_customer_trx_lines_all.amount_due_remaining%TYPE
	 );

	 TYPE payment_sch_tbl_type IS TABLE OF payment_sch_rec_type;
	 
	 TYPE contract_inv_hdr IS RECORD(
		x_invoice_number        		ra_customer_trx_all.trx_number%TYPE
      ,x_invoice_date         	    ra_customer_trx_all.trx_date%TYPE
      ,x_invoice_amount         		ar_payment_schedules_all.amount_due_original%TYPE
      ,x_invoice_due_date    	    ar_payment_schedules_all.due_date%TYPE
      ,x_amount_due_remaining      ar_payment_schedules_all.amount_due_remaining%TYPE
	  ,x_currency       				ra_customer_trx_all.invoice_currency_code%TYPE
	  ,x_amount_applied       		ar_payment_schedules_all.amount_applied%TYPE
	  ,x_amount_adjusted      		ar_payment_schedules_all.amount_adjusted%TYPE
	  ,x_amount_credited      		ar_payment_schedules_all.amount_credited%TYPE
	  ,x_payment_term      			ra_terms.name%TYPE	  	 
	 );
	 
	 
	 TYPE contract_inv_hdr_tbl_type IS TABLE OF contract_inv_hdr;
	 
	TYPE contract_pmt_rec_type IS RECORD
     (
		 x_payment_type        				 ra_customer_trx_lines_all.interface_line_attribute9%TYPE
		,x_amount        					 ra_customer_trx_lines_all.unit_selling_price%TYPE
		,x_late_policy_exempt                okl_strm_type_exempt.late_policy_exempt_yn%TYPE
		,x_late_int_ass_yn                   okl_txd_ar_ln_dtls_b.late_int_ass_yn%TYPE
	 );

	 TYPE contract_pmt_tbl_type IS TABLE OF contract_pmt_rec_type;
	
	TYPE cont_receipt_rec_type IS RECORD
     (
		 x_receipt_number        		ar_cash_receipts_all.receipt_number%TYPE
		,x_receipt_date        			ar_cash_receipts_all.receipt_date%TYPE
		,x_receipt_amount            	ar_cash_receipts_all.amount%TYPE
		,x_receipt_amt_applied     		ar_receivable_applications_all.amount_applied%TYPE
		,x_onaccount_amount     		ar_receivable_applications_all.amount_applied%TYPE
		,x_receipt_method      			ar_receipt_methods.name%TYPE
		,x_receipt_status         		ar_cash_receipts_all.status%TYPE
		,x_rev_reason_desc     			ar_lookups.description%TYPE
	 );

	 TYPE cont_receipt_tbl_type IS TABLE OF cont_receipt_rec_type;
	 
	TYPE contract_inv_rec_type IS RECORD
     (
		x_contract_inv_hdr 		contract_inv_hdr
		,x_contract_pmt_tbl_type contract_pmt_tbl_type
		,x_cont_receipt_tbl_type cont_receipt_tbl_type
	 );

     TYPE contract_inv_tbl_type IS TABLE OF contract_inv_rec_type;
	 

	TYPE inv_main_pmt_rec_type IS RECORD
    (
		 x_contract_num        	contract_num_rec_type
		,x_pmt_schedule           payment_sch_tbl_type
		,x_contract_inv         contract_inv_tbl_type
    );
    TYPE inv_main_pmt_tbl_type IS TABLE OF inv_main_pmt_rec_type;
	
	
	-------------------Receipt -> invoices history --------------------------------
	 
	 
	  TYPE cont_inv_rec_type IS RECORD(
		x_invoice_number        		ra_customer_trx_all.trx_number%TYPE
      ,x_invoice_date         	    ra_customer_trx_all.trx_date%TYPE
      ,x_invoice_amount         		ar_payment_schedules_all.amount_due_original%TYPE
      ,x_invoice_due_date    	    ar_payment_schedules_all.due_date%TYPE
      ,x_amount_due_remaining      ar_payment_schedules_all.amount_due_remaining%TYPE
	  ,x_currency       				ra_customer_trx_all.invoice_currency_code%TYPE
	  ,x_amount_applied       		ar_payment_schedules_all.amount_applied%TYPE
	  ,x_amount_adjusted      		ar_payment_schedules_all.amount_adjusted%TYPE
	  ,x_amount_credited      		ar_payment_schedules_all.amount_credited%TYPE
	  ,x_payment_term      			ra_terms.name%TYPE	 
	  ,x_receipt_amt_applied     	ar_receivable_applications_all.amount_applied%TYPE	
		  
	 );	 	 
	 TYPE cont_inv_tbl_type IS TABLE OF cont_inv_rec_type;
	 
	 TYPE cont_recpt_rec_type IS RECORD
     (
		 x_receipt_number        		ar_cash_receipts_all.receipt_number%TYPE
		,x_receipt_date        			ar_cash_receipts_all.receipt_date%TYPE
		,x_receipt_amount            	ar_cash_receipts_all.amount%TYPE
		,x_onaccount_amount     		ar_receivable_applications_all.amount_applied%TYPE
		,x_unapplied_amount     		ar_receivable_applications_all.amount_applied%TYPE
		,x_receipt_method      			ar_receipt_methods.name%TYPE
		,x_receipt_status         		ar_cash_receipts_all.status%TYPE
		,x_rev_reason_desc     			ar_lookups.description%TYPE
	 );

	 TYPE cont_recpt_tbl_type IS TABLE OF cont_recpt_rec_type;
	 
	 
	 TYPE contInvRecType IS RECORD
     (	
		x_contract_inv_hdr     cont_inv_rec_type
       ,x_contract_pmt_tbl_type      contract_pmt_tbl_type			
	 );
	 TYPE contInvTblType IS TABLE OF contInvRecType;	 
	 
	TYPE contract_rcv_rec_type IS RECORD
     (		
		x_cont_receipt_tbl_type cont_recpt_rec_type
		,x_contInvRecType     contInvTblType		
	 );

     TYPE contract_rcv_tbl_type IS TABLE OF contract_rcv_rec_type;	 

	TYPE inv_main_rcpt_rec_type IS RECORD
    (
		 x_contract_num        	contract_num_rec_type
		,x_contract_rcv         contract_rcv_tbl_type
    );
    TYPE inv_main_rcpt_tbl_type IS TABLE OF inv_main_rcpt_rec_type;
	
	
	
------------------------Receipt-> invoices  history ------------------------------
------------------------end to end testing api------------------------------------------------------------

 TYPE contractHdrRecType IS RECORD
     (
	  x_contract_number        		OKC_K_HEADERS_ALL_B.contract_number%TYPE
      ,x_loan_start_date         	OKC_K_HEADERS_ALL_B.start_date%TYPE
      ,x_loan_end_date          		OKC_K_HEADERS_ALL_B.end_date%TYPE
	  ,x_payment_frequency            FND_LOOKUPS.meaning%TYPE
	  ,x_book_classification          fnd_lookup_values.meaning%TYPE
	 );
	 
	  TYPE contractHdrTblType IS TABLE OF contractHdrRecType;


TYPE contractRcptRecType IS RECORD
     (
		 x_receipt_number        		ar_cash_receipts_all.receipt_number%TYPE
		,x_receipt_date        			ar_cash_receipts_all.receipt_date%TYPE
		,x_receipt_amount            	ar_cash_receipts_all.amount%TYPE
		,x_receipt_method      			ar_receipt_methods.name%TYPE
		,x_onaccount_amount     		ar_receivable_applications_all.amount_applied%TYPE
		,x_receipt_status         		ar_cash_receipts_all.status%TYPE
		,x_rev_reason_desc     			ar_lookups.description%TYPE
	 );

 TYPE contractRcptTblType IS TABLE OF contractRcptRecType;


 TYPE contractInvRecType IS RECORD(
      x_invoice_date         	    ra_customer_trx_all.trx_date%TYPE
      ,x_invoice_amount         	ar_payment_schedules_all.amount_due_original%TYPE
	  ,x_amount_applied       		ar_payment_schedules_all.amount_applied%TYPE 
	  ,x_payment_type        		ra_customer_trx_lines_all.interface_line_attribute9%TYPE
	  ,x_receipt_amt_app            ar_receivable_applications_all.amount_applied%TYPE
	 );
	  TYPE contractInvTblType IS TABLE OF contractInvRecType;


 TYPE outstandingRecType IS RECORD(
    --  x_invoice_due_date         	    ar_payment_schedules_all.due_date%TYPE
      x_amount_remaining         	ar_payment_schedules_all.amount_due_remaining%TYPE
	  --,x_transaction_type        		ra_customer_trx_lines_all.interface_line_attribute9%TYPE
	 );
	 
	 TYPE outstandingTblType IS TABLE OF outstandingRecType;
	 
	  TYPE nextPmtRecType IS RECORD(
       x_due_date         	    	ar_payment_schedules_all.due_date%TYPE
      ,x_amount_remaining         	ar_payment_schedules_all.amount_due_remaining%TYPE
	 -- ,x_transaction_type        	ra_customer_trx_lines_all.interface_line_attribute9%TYPE
	 );
	 
	 TYPE nextPmtTblType IS TABLE OF nextPmtRecType;

TYPE contractTrxRecType IS RECORD
     (
		
		x_cont_receipt_tbl_type    contractRcptTblType
		,x_contract_inv_hdr 		contractInvTblType
	 );

     TYPE contractTrxTblType IS TABLE OF contractTrxRecType;	 

	TYPE mainTrxDataType IS RECORD
    (
		 xContHdrData        	contractHdrTblType
		,xConTrxData         	contractTrxTblType
		,xConOutstandingData        outstandingTblType
		,xConNextPmtData         	nextPmtTblType
    );
    TYPE mainTrxDataTblType IS TABLE OF mainTrxDataType;
------------------------------------------------------------------------------------



  TYPE onacct_rec_type IS RECORD
     (	  
      x_receipt_number           ar_cash_receipts_all.receipt_number%TYPE
	 ,x_receipt_date             ar_cash_receipts_all.receipt_date%TYPE
	 ,x_onaccount_amount         ar_receivable_applications_all.amount_applied%TYPE
	 ,x_receipt_method      	 ar_receipt_methods.name%TYPE
	 );

TYPE onacct_tbl_type IS TABLE OF onacct_rec_type;


TYPE cont_cache_rec_type IS RECORD
     (
	 x_contract_number        		OKC_K_HEADERS_ALL_B.contract_number%TYPE
	  ,x_contract_desc               okc_k_headers_tl.short_description%TYPE
      ,x_loan_start_date         	OKC_K_HEADERS_ALL_B.start_date%TYPE
      ,x_loan_end_date          		OKC_K_HEADERS_ALL_B.end_date%TYPE
	  ,x_payment_frequency            FND_LOOKUPS.meaning%TYPE
	 );

	 TYPE cont_cache_tbl_type IS TABLE OF cont_cache_rec_type;
	 ---------------------------------BANK Related Types---------------------------------------------------------

TYPE contPdcRecType IS RECORD
(
  x_acct_holder_name VARCHAR2(350)
 ,x_bank_name  		xxmobl_pdc_pymt_all_t.bank_nm%TYPE
,x_branch_name  	xxmobl_pdc_pymt_all_t.bank_brnch_nm%TYPE
,x_check_num  		xxmobl_pdc_pymt_all_t.pymt_recv_chk_num%TYPE
,x_check_date		xxmobl_pdc_pymt_all_t.pymt_recv_chk_dt%TYPE
,x_check_amt		xxmobl_pdc_pymt_all_t.pymt_recv_chk_amt%TYPE
);

 TYPE contPdcTblType IS TABLE OF contPdcRecType;
	 
---------------------------------BANK Related Types---------------------------------------------------------


END XXRCSS_TYPES_PK;

/