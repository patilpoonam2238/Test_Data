create or replace PACKAGE BODY XXRCSS_BANK_PKG AS


PROCEDURE main_bank_summary
 (
  p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
  ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_bank_hdr_main OUT nocopy XXRCSS_TYPES_PK.contPdcTblType
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
)
IS


ex_missing_bank_details EXCEPTION ;

l_err_message VARCHAR2(4000);
l_err_code  NUMBER;

l_error_message VARCHAR2(4000):= null;
l_error_code  NUMBER :=0;

l_contract_num 		okc_k_headers_all_b.contract_number%TYPE;
l_contract_number  okc_k_headers_all_b.contract_number%TYPE;
l_cust_acct_number hz_cust_accounts_all.account_number%TYPe;
l_org_id             okc_k_headers_all_b.authoring_org_id%TYPE;

l_account_count NUMBER :=0;

BEGIN

DBMS_output.put_line('p_contract_number'||p_contract_number);
DBMS_output.put_line('p_cust_acct_number'||p_cust_acct_number);

IF (p_contract_number IS NOT NULL OR p_cust_acct_number IS NOT NULL) THEN

dbms_output.put_line('Validate Parameters');


IF p_contract_number IS NOT NULL THEN
BEGIN
dbms_output.put_line('Validate Contract Number');

SELECT chr.contract_number
  INTO l_contract_number
  FROM  okc_k_headers_all_b chr
  WHERE  chr.contract_number = p_contract_number
  AND   chr.sts_code ='BOOKED';

EXCEPTION
WHEN NO_DATA_FOUND THEN
l_error_message  :='Contract Number is Invalid or Contract not yet BOOKED.';
l_error_code     := 1;
DBMS_output.put_line(x_error_message);

WHEN OTHERS THEN
l_error_message  :='Error occured while validating contract number.'||SQLERRM;
l_error_code     := 1;
DBMS_output.put_line(x_error_message);
END;
END IF;


IF p_cust_acct_number IS NOT NULL THEN
BEGIN
dbms_output.put_line('Validate Customer Account Number');

SELECT account_number
INTO l_cust_acct_number
FROM hz_cust_accounts_all hca
WHERE hca.account_number =p_cust_acct_number
AND  hca.status = 'A';


IF l_cust_acct_number IS NOT NULL THEN

SELECT count(*)
  INTO l_account_count
  FROM  okc_k_headers_all_b chr
        ,hz_cust_accounts_all hca
  WHERE  chr.cust_acct_id =hca.cust_account_id
  AND   hca.account_number  = l_cust_acct_number
  AND   chr.sts_code ='BOOKED'
  AND   hca.status = 'A';

 IF   l_account_count = 0 THEN
 l_error_message  :=l_error_message||'For entered Customer Account Number, Contract not available in BOOKED state.';
l_error_code     := 1;
DBMS_output.put_line(x_error_message);
 END IF;

END IF;

EXCEPTION
WHEN NO_DATA_FOUND THEN
l_error_message  :=l_error_message||'Entered Customer Account Number is Invalid or Incorrect.';
l_error_code     := 1;
DBMS_output.put_line(x_error_message);

WHEN OTHERS THEN
l_error_message  :=l_error_message||'Error occured while validating Customer Account Number.'||SQLERRM;
l_error_code     := 1;
DBMS_output.put_line(x_error_message);
END;
END IF;

dbms_output.put_line('l_error_message '||l_error_message);
dbms_output.put_line('l_error_code '||l_error_code);
IF l_error_message IS NULL and l_error_code <> 1 THEN

BEGIN
dbms_output.put_line('Calling Validate Contract Proc to verify combination of parameters');

 XXRCSS_UTIL_PKG.validate_contract(p_contract_number,p_cust_acct_number,l_contract_num);

dbms_output.put_line('Contract Number-'||l_contract_num);
EXCEPTION
WHEN OTHERS THEN
x_error_message  :='Error occured while validating contract number.'||SQLERRM;
x_error_code     := 1;
DBMS_output.put_line(x_error_message);
END;

IF l_contract_num IS NOT NULL THEN

dbms_output.put_line('Get org details');
l_org_id :=XXRCSS_UTIL_PKG.get_org_details(l_contract_num);

MO_GLOBAL.set_policy_context('S',l_org_id);

BEGIN
DBMS_output.put_line('Getting Bank header details for mentioned contract');

SELECT xpat.Frst_Nm || ' ' || xpat.Mid_Nm || ' ' || xpat.Last_Nm As Acct_Holder_name 
 , xppa.bank_nm
,xppa.bank_brnch_nm
,xppa.PYMT_RECV_CHK_NUM
,xppa.PYMT_RECV_CHK_DT
,xppa.PYMT_RECV_CHK_AMT
BULK COLLECt INTO x_bank_hdr_main
FROM okc_k_headers_all_b chr
    ,hz_cust_accounts_all hca
    ,XXMOBL_BASE_EXTND_XREF_T xbe
    ,xxmobl_pdc_pymt_all_t xppa
    ,XXMOBL_PRTY_CUST_XREF_T  xpcx
	,XXMOBL_PRTY_ALL_T  xpat
WHERE hca.cust_account_id= chr.cust_acct_id
AND  chr.contract_number = xbe.contract_number
AND  xbe.cr_appl_id = xppa.cr_appl_id
AND  chr.cust_acct_id =xpcx.account_number
AND  to_char(xpcx.prty_id) =hca.orig_system_reference
AND xppa.prty_id 		   =xpat.prty_id
AND chr.contract_number = NVL(p_contract_number,chr.contract_number)
AND hca.account_number = NVL(p_cust_acct_number,hca.account_number);


 
IF x_bank_hdr_main.count =0 THEN
Raise ex_missing_bank_details;
END iF;
l_err_message        :=null;
l_err_code  		 := 0;

EXCEPTION
WHEN ex_missing_bank_details THEN
l_err_message  :=l_err_message||'PDC details for mentioned contract not found.Please verify contract number.';
l_err_code     := 1;
DBMS_output.put_line(l_err_message);

WHEN OTHERS THEN
l_err_message  :=l_err_message||'Unexpected error occured while fetching PDC details.'||SQLERRM;
l_err_code     := 1;
DBMS_output.put_line(l_err_message);

END;


ELSE  --paramters combination incorrect
x_error_message  :='Combination of parameters entered is Invalid please enter correct parameters.';
x_error_code     := 1;
END IF;

ELSE ---paramters invalid
x_error_message := l_error_message;
x_error_code    := l_error_code;

END IF;
ELSE --no paramters entered
x_error_message  :='Please provide at least one Input Parameter:Contract Number or Customer Account Number.';
x_error_code     := 1;
DBMS_output.put_line(x_error_message);

END IF;

EXCEPTION
WHEN OTHERS THEN
x_error_message  :='Error occured while fetching PDC details.'||SQLERRM;
x_error_code     := 1;
DBMS_output.put_line(x_error_message);

END main_bank_summary;

END XXRCSS_BANK_PKG;
/