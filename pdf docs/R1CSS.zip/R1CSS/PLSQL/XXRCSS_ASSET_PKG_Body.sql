create or replace PACKAGE BODY XXRCSS_ASSET_PKG AS

PROCEDURE main_asset_info
( p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_asset_info    	  OUT nocopy XXRCSS_TYPES_PK.asset_tbl_type
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
)
IS
ex_missing_asset_details EXCEPTION;
l_cust_acct_id   hz_cust_accounts_all.cust_account_id%TYPE;

l_error_message VARCHAR2(4000):=null;
l_error_code  NUMBER :=0;
l_account_count NUMBER;

l_err_message VARCHAR2(4000);
l_err_code  NUMBER;

BEGIN

DBMS_output.put_line('p_cust_acct_number'||p_cust_acct_number);


IF p_cust_acct_number IS NOT NULL THEN
BEGIN
dbms_output.put_line('Validate Customer Account Number');

SELECT cust_account_id
INTO l_cust_acct_id
FROM hz_cust_accounts_all hca
WHERE hca.account_number =p_cust_acct_number
AND  hca.status = 'A';


IF l_cust_acct_id IS NOT NULL THEN

SELECT count(*)
  INTO l_account_count
  FROM  okc_k_headers_all_b chr
        ,hz_cust_accounts_all hca
  WHERE  chr.cust_acct_id =hca.cust_account_id
  AND   hca.cust_account_id  = l_cust_acct_id
  AND   chr.sts_code ='BOOKED'
  AND   hca.status = 'A';

 IF   l_account_count = 0 THEN
 l_error_message  :=l_error_message||'For entered Customer Account Number, Contract not available in BOOKED state.';
l_error_code     := 1;
DBMS_output.put_line(x_error_message);
 END IF;

END IF;

EXCEPTION
WHEN NO_DATA_FOUND THEN
l_error_message  :=l_error_message||'Entered Customer Account Number is Invalid or Incorrect.';
l_error_code     := 1;
DBMS_output.put_line(x_error_message);

WHEN OTHERS THEN
l_error_message  :=l_error_message||'Error occured while validating customer account Number.'||SQLERRM;
l_error_code     := 1;
DBMS_output.put_line(x_error_message);
END;

dbms_output.put_line('l_error_message '||l_error_message);
dbms_output.put_line('l_error_code '||l_error_code);
IF l_error_message IS NULL and l_error_code <> 1 THEN

BEGIN
DBMS_output.put_line('Getting asset  details');
 SELECT distinct chr.contract_number contract_number
                ,kle_m.model_number
		        ,mtl.description     item_description
		        ,inst.serial_number  chasis_number
               ,(SELECT rul.rule_information4
               FROM okc_rule_groups_b rgp
                    ,okc_rules_b       rul
               WHERE  rgp.dnz_chr_id      = chr.id
        AND   rul.rgp_id          = rgp.id
        AND   rgp.rgd_code        in( 'LAAFLG')
        AND   rul.dnz_chr_id      = rgp.dnz_chr_id
        AND   rul.rule_information_category in( 'LAFLTL')
        AND   rgp.cle_id          = cle33.id) registration_number
            ,kle.attribute3      engine_number
               ,kle_m.manufacturer_name
                ,clet_fin.name asset_number
		 BULK COLLECT INTO x_asset_info
		 FROM okc_k_headers_all_b    chr,
		      okc_k_items            itm,
			  okc_k_lines_b          cle33,
			  okc_k_lines_b          cle34,
			  okl_k_Lines            kle,
			  mtl_system_items_b     mtl,
			  okl_txl_itm_insts      inst
              ,okc_k_lines_tl   clet_fin
               ,okc_k_items         okc_m
               , okc_k_lines_b       cle_m
                ,okl_k_lines         kle_m
		WHERE chr.id              = cle33.dnz_chr_id
		AND   cle33.lse_id        = 33
		AND   cle34.lse_id        = 34
		AND   cle33.id            = cle34.cle_id
		AND   cle33.id            = kle.id
		AND   cle34.id            = itm.cle_id
        AND  cle33.id = clet_fin.id
        AND   cle_m.id = okc_m.cle_id
        AND   cle_m.dnz_chr_id = chr.id
        AND   kle_m.id = cle_m.id
        and   cle_m.cle_id=kle.id
		AND   itm.jtot_object1_code = 'OKX_SYSITEM'
        AND   okc_m.jtot_object1_code = 'OKX_ASSET'
		AND   itm.object1_id1  = mtl.inventory_item_id
		AND   itm.object1_id2  = mtl.organization_id
		AND   inst.dnz_cle_id  = cle33.id
        AND  chr.cust_acct_id =l_cust_acct_id
        AND chr.sts_code ='BOOKED'
		AND   inst.tal_type IN ('CFA','CRL');

IF x_asset_info.count =0 THEN
Raise ex_missing_asset_details;
END iF;

l_err_message  :=null;
l_err_code     := 0;

EXCEPTION
WHEN ex_missing_asset_details THEN
l_err_message  :=l_err_message||'Asset details for mentioned Customer Account Number not found..';
l_err_code     := 1;
DBMS_output.put_line(l_err_message);

WHEN OTHERS THEN
l_err_message  :=l_err_message||'Unexpected error occured while fetching asset details.'||SQLERRM;
l_err_code     := 1;
DBMS_output.put_line(l_err_message);

END;



ELSE ---paramter invalid
x_error_message := l_error_message;
x_error_code    := l_error_code;
END IF;

ELSE --no paramters entered
x_error_message  :='Please enter requested parameter,Customer Account Number.';
x_error_code     := 1;
DBMS_output.put_line(x_error_message);
END IF;

END main_asset_info;


END XXRCSS_ASSET_PKG;
/