CREATE OR REPLACE PACKAGE XXRCSS_WEBSERVICES AS 
/* $Header: $ */
/*#
* This interface returns the Customer Information .
* @rep:scope public
* @rep:product XXJDFL
* @rep:displayname XXRCSS_WEBSERVICES
* @rep:lifecycle active
* @rep:compatibility S
* @rep:category BUSINESS_ENTITY XXJDFL_CUSTOMER
*/

/*---------------------------------------------------------------------------------------
  Package: XXRCSS_WEBSERVICES

  Description: This Package Contains Customer API's

  Change Log:
------------------------------------------------------------------------------------------
  PPATIL  05/10/2020    Initial Development

-----------------------------------------------------------------------------------------*/


/*#
* Returns Customer Information 
* @param p_contract_number VARCHAR2 Contract Number
* @param p_cust_acct_id NUMBER Customer Account ID 
* @param p_cust_acct_number VARCHAR2 Customer Account Number
* @param x_cust_info table type to get customer information
* @param x_address_loc table type to get customer address information
* @param x_alt_emails table type to get customer alternate email information
* @param x_alt_phone table type to get customer phone information
* @param x_error_code An error code if an error is encountered.
* @param x_error_message  An error message if an error is encountered
* @rep:scope public
* @rep:lifecycle active
* @rep:displayname Return Customer Information
*/
PROCEDURE main_cust_info
(p_contract_number     IN okc_k_headers_all_b.contract_number%TYPE
  ,p_cust_acct_id      IN okc_k_headers_all_b.cust_acct_id%TYPE
  ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_cust_info    	  OUT nocopy XXRCSS_TYPES_PK.cust_tbl_type
  ,x_address_loc      OUT nocopy XXRCSS_TYPES_PK.loc_tbl_type
  ,x_alt_emails       OUT nocopy XXRCSS_TYPES_PK.email_tbl_type
  ,x_alt_phone        OUT nocopy XXRCSS_TYPES_PK.phone_tbl_type    
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
);

/*#
* Returns Asset Information 
* @param p_cust_acct_number VARCHAR2 Customer Account Number
* @param x_asset_info table type to get asset information
* @param x_error_code An error code if an error is encountered.
* @param x_error_message  An error message if an error is encountered
* @rep:scope public
* @rep:lifecycle active
* @rep:displayname Return Asset Information
*/
 PROCEDURE main_asset_info
( p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_asset_info    	  OUT nocopy XXRCSS_TYPES_PK.asset_tbl_type    
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
);

/*#
* Returns Contract header Information 
* @param p_contract_number VARCHAR2 Contract Number
* @param p_cust_acct_number VARCHAR2 Customer Account Number
* @param x_contract_info table type to get contract header information
* @param x_latePolicyTblType table type to get late policy information.
* @param x_error_code An error code if an error is encountered.
* @param x_error_message  An error message if an error is encountered
* @rep:scope public
* @rep:lifecycle active
* @rep:displayname Return Contract Information
*/
 PROCEDURE main_contract_summary
 ( 
  p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
  ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_contract_info    	  OUT nocopy XXRCSS_TYPES_PK.contract_main_tbl_type   
  ,x_latePolicyTblType  OUT nocopy  XXRCSS_TYPES_PK.latePolicyTblType 
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
);

/*#
* Returns Contract Transactions Information 
* @param p_contract_number VARCHAR2 Contract Number
* @param p_cust_acct_number VARCHAR2 Customer Account Number
* @param x_inv_pmt_rec_type table type to get contract transaction information
* @param x_onacct_rec_type table type to get on account receipt information
* @param x_error_code An error code if an error is encountered.
* @param x_error_message  An error message if an error is encountered
* @rep:scope public
* @rep:lifecycle active
* @rep:displayname Return Contract Transactions Information
*/
 PROCEDURE main_cont_transactions
 ( 
  p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
  ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_inv_pmt_rec_type    	  OUT nocopy XXRCSS_TYPES_PK.inv_main_pmt_tbl_type   
  ,x_onacct_rec_type   OUT nocopy XXRCSS_TYPES_PK.onacct_tbl_type  
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
);

/*#
* Returns Contract Payment Schedule Information 
* @param p_contract_number VARCHAR2 Contract Number
* @param x_inv_pmt_rec_type table type to get contract schedule information
* @param x_tax_percent_th table type to get tax percentage for Thailand information
* @param x_error_code An error code if an error is encountered.
* @param x_error_message  An error message if an error is encountered
* @rep:scope public
* @rep:lifecycle active
* @rep:displayname Return Payment Schedule Information
*/
 PROCEDURE main_schedule_details
 ( 
  p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
  ,x_inv_pmt_rec_type    	  OUT nocopy XXRCSS_TYPES_PK.inv_main_pmt_tbl_type    
  ,x_tax_percent_th       OUT nocopy NUMBER
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
);

/*#
* Returns Contract Testing Information 
* @param p_contract_number VARCHAR2 Contract Number
* @param p_cust_acct_number VARCHAR2 Customer Account Number
* @param x_main_test_data table type to get contract related all information
* @param x_error_code An error code if an error is encountered.
* @param x_error_message  An error message if an error is encountered
* @rep:scope public
* @rep:lifecycle active
* @rep:displayname Return Contract Testing Information
*/
 PROCEDURE main_test_data
 ( 
  p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
  ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_main_test_data OUT nocopy XXRCSS_TYPES_PK.mainTrxDataTblType   
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
);

/*#
* Returns Contract Payments Information 
* @param p_contract_number VARCHAR2 Contract Number
* @param p_cust_acct_number VARCHAR2 Customer Account Number
* @param x_inv_rcpt_rec_type table type to get contract Payments information
* @param x_error_code An error code if an error is encountered.
* @param x_error_message  An error message if an error is encountered
* @rep:scope public
* @rep:lifecycle active
* @rep:displayname Return Contract Payments Information
*/
 PROCEDURE main_pmt_history
 ( 
  p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
  ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_inv_rcpt_rec_type    	  OUT nocopy XXRCSS_TYPES_PK.inv_main_rcpt_tbl_type    
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
);


/*#
* Returns Contract PDC Information 
* @param p_contract_number VARCHAR2 Contract Number
* @param p_cust_acct_number VARCHAR2 Customer Account Number
* @param x_bank_hdr_main table type to get contract pdc information
* @param x_error_code An error code if an error is encountered.
* @param x_error_message  An error message if an error is encountered
* @rep:scope public
* @rep:lifecycle active
* @rep:displayname Return Contract PDC Information
*/
 PROCEDURE main_bank_summary
 ( 
  p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
  ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_bank_hdr_main    	  OUT nocopy XXRCSS_TYPES_PK.contPdcTblType    
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
);

END XXRCSS_WEBSERVICES;
/