create or replace PACKAGE BODY XXRCSS_CUSTOMER_PKG AS

PROCEDURE main_cust_info
(p_contract_number     IN okc_k_headers_all_b.contract_number%TYPE
  ,p_cust_acct_id      IN okc_k_headers_all_b.cust_acct_id%TYPE
  ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_cust_info    	  OUT nocopy XXRCSS_TYPES_PK.cust_tbl_type
  ,x_address_loc      OUT nocopy XXRCSS_TYPES_PK.loc_tbl_type
  ,x_alt_emails       OUT nocopy XXRCSS_TYPES_PK.email_tbl_type
  ,x_alt_phone        OUT nocopy XXRCSS_TYPES_PK.phone_tbl_type    
  ,x_error_message          OUT nocopy VARCHAR2
  ,x_error_code  		      OUT nocopy NUMBER
)
IS

ex_missing_customer_details EXCEPTION ;
ex_missing_address_details EXCEPTION ;
no_alt_phone_found EXCEPTION;
no_alt_email_found EXCEPTION;

l_err_message VARCHAR2(4000);
l_err_code  NUMBER;

l_error_message VARCHAR2(4000):=null;
l_error_code  NUMBER :=0;

l_party_id hz_parties.party_id%TYPE;
l_contract_num 		okc_k_headers_all_b.contract_number%TYPE;
l_cust_acct_id   	okc_k_headers_all_b.cust_acct_id%TYPE;
l_cust_acct_number  hz_cust_accounts_all.account_number%TYPE;

l_contract_number  okc_k_headers_all_b.contract_number%TYPE;

l_custid_count  NUMBER :=0;
l_account_count NUMBER :=0;

CURSOR party_data_cur IS
SELECT distinct hps.party_id,hps.party_site_id,hca.account_number--,count(hps.party_site_id)
    FROM okc_k_headers_all_b chr
	    ,hz_cust_accounts_all hca
		,hz_cust_acct_sites_all hcasa
		,hz_party_sites hps
		,HZ_CUST_SITE_USES_ALL HCSUA
        ,hz_parties hp
		,hr_operating_units hou
 WHERE   chr.cust_acct_id = hca.cust_account_id
         AND hcasa.party_site_id = hps.party_site_id
         AND hp.party_id =hps.party_id 
         AND hcasa.cust_acct_site_id=hcsua.cust_acct_site_id
         AND hca.party_id=hp.party_id
         AND hca.cust_account_id =hcasa.cust_account_id
		 AND hou.organization_id =chr.org_id
		 AND hou.organization_id =hcasa.org_id
         AND hcsua.status  = 'A'
         AND hca.status    = 'A'	
		 AND  hp.status    = 'A'
		 AND hcasa.status  = 'A'
		 AND chr.sts_code  ='BOOKED'
         AND chr.contract_number  = NVL(p_contract_number,chr.contract_number)
		 AND hca.cust_account_id = NVL(p_cust_acct_id,hca.cust_account_id)
		 AND hca.account_number = NVL(p_cust_acct_number,hca.account_number);
		 

BEGIN

DBMS_output.put_line('p_contract_number'||p_contract_number);
DBMS_output.put_line('p_cust_acct_id'||p_cust_acct_id);
DBMS_output.put_line('p_cust_acct_number'||p_cust_acct_number);

IF (p_contract_number IS NOT NULL OR p_cust_acct_id IS NOT NULL OR p_cust_acct_number IS NOT NULL) THEN 

dbms_output.put_line('Validate Parameters');


IF p_contract_number IS NOT NULL THEN 
BEGIN
dbms_output.put_line('Validate Contract Number');

SELECT chr.contract_number 
  INTO l_contract_number 
  FROM  okc_k_headers_all_b chr
  WHERE  chr.contract_number = p_contract_number
  AND   chr.sts_code ='BOOKED';

EXCEPTION
WHEN NO_DATA_FOUND THEN
l_error_message  :='Contract Number is Invalid or Contract not yet BOOKED.';
l_error_code     := 1;
DBMS_output.put_line(x_error_message);

WHEN OTHERS THEN
l_error_message  :='Error occured while validating contract number.'||SQLERRM;
l_error_code     := 1;
DBMS_output.put_line(x_error_message);
END;
END IF;

IF p_cust_acct_id IS NOT NULL THEN 

BEGIN
dbms_output.put_line('Validate Customer Account ID');

SELECT cust_account_id
INTO l_cust_acct_id
FROM hz_cust_accounts_all hca
WHERE hca.cust_account_id =p_cust_acct_id
AND  hca.status = 'A';

IF l_cust_acct_id IS NOT NULL THEN 

SELECT count(*) 
  INTO l_custid_count
  FROM  okc_k_headers_all_b chr
        ,hz_cust_accounts_all hca
  WHERE  chr.cust_acct_id =hca.cust_account_id
  AND   chr.cust_acct_id  = l_cust_acct_id
  AND   chr.sts_code ='BOOKED'
  AND   hca.status = 'A';

 IF   l_custid_count =0 THEN 
 l_error_message  :=l_error_message||'For entered Customer Account ID, Contract not available in BOOKED state.';
l_error_code     := 1;
DBMS_output.put_line(x_error_message);
 END IF;

END IF;  
EXCEPTION
WHEN NO_DATA_FOUND THEN
l_error_message  :=l_error_message||'Entered Customer Account ID is Invalid or Incorrect.';
l_error_code     := 1;
DBMS_output.put_line(x_error_message);

WHEN OTHERS THEN
l_error_message  :=l_error_message||'Error occured while validating customer account ID.'||SQLERRM||SQLcode;
l_error_code     := 1;
DBMS_output.put_line(x_error_message);
END;

END IF;


IF p_cust_acct_number IS NOT NULL THEN
BEGIN
dbms_output.put_line('Validate Customer Account Number');

SELECT account_number
INTO l_cust_acct_number
FROM hz_cust_accounts_all hca
WHERE hca.account_number =p_cust_acct_number
AND  hca.status = 'A';


IF l_cust_acct_number IS NOT NULL THEN 

SELECT count(*) 
  INTO l_account_count
  FROM  okc_k_headers_all_b chr
        ,hz_cust_accounts_all hca
  WHERE  chr.cust_acct_id =hca.cust_account_id
  AND   hca.account_number  = l_cust_acct_number
  AND   chr.sts_code ='BOOKED'
  AND   hca.status = 'A';

 IF   l_account_count = 0 THEN 
 l_error_message  :=l_error_message||'For entered Customer Account Number, Contract not available in BOOKED state.';
l_error_code     := 1;
DBMS_output.put_line(x_error_message);
 END IF;

END IF; 

EXCEPTION
WHEN NO_DATA_FOUND THEN
l_error_message  :=l_error_message||'Entered Customer Account Number is Invalid or Incorrect.';
l_error_code     := 1;
DBMS_output.put_line(x_error_message);

WHEN OTHERS THEN
l_error_message  :=l_error_message||'Error occured while validating customer account Number.'||SQLERRM;
l_error_code     := 1;
DBMS_output.put_line(x_error_message);
END;
END IF;

dbms_output.put_line('l_error_message '||l_error_message);
dbms_output.put_line('l_error_code '||l_error_code);
IF l_error_message IS NULL and l_error_code <> 1 THEN 

BEGIN
dbms_output.put_line('Calling Validate Contract Proc to verify combination of parameters');

 XXRCSS_UTIL_PKG.validate_contract(p_contract_number,p_cust_acct_id,p_cust_acct_number,l_contract_num);

dbms_output.put_line('Contract Number-'||l_contract_num);
EXCEPTION
WHEN OTHERS THEN
x_error_message  :='Error occured while validating contract number.'||SQLERRM;
x_error_code     := 1;
DBMS_output.put_line(x_error_message);
END;

IF l_contract_num IS NOT NULL THEN 

BEGIN
DBMS_output.put_line('Getting Customer personal details');


select distinct hp.party_name
		,hp.party_type
		,hou.name org_name
		,hp.party_id
        ,hca.account_number cust_acct_num
		,hp.jgzz_fiscal_code party_unique_id
        ,hp.person_first_name party_first_name
        ,hp.person_last_name party_last_name
        ,hp.person_middle_name party_middle_name
        ,hp.person_previous_last_name party_maiden_name
        ,hp.known_as alias_name
        ,hp.primary_phone_number party_primary_phone_number
        ,hp.email_address  party_email_address
        ,obj_hp.person_first_name contact_first_name
        ,obj_hp.person_last_name contact_last_name
        ,obj_hp.person_middle_name contact_middle_name
        ,obj_hp.person_previous_last_name contact_maiden_name
       ,hpp.date_of_birth  DOB
        ,obj_hp.jgzz_fiscal_code contact_unique_id
        ,obj_hp.primary_phone_number contact_primary_phone_number
        ,obj_hp.email_address  contact_email_address    
BULK COLLECT INTO x_cust_info		
from  okc_k_headers_all_b chr 
      ,hz_cust_accounts_all hca
      ,hz_parties hp
      ,hr_operating_units hou
      ,hz_person_profiles hpp
     , (select per_hp.*
            ,hr.subject_id subject_id
      FROM hz_relationships hr
          ,hz_parties per_hp
     WHERE hr.object_id = per_hp.party_id) obj_hp
where hca.cust_account_id =chr.cust_acct_id
AND chr.authoring_org_id =hou.organization_id
AND hca.party_id = hp.party_id
AND obj_hp.subject_id(+) = hp.party_id
AND hpp.party_id(+) = hp.party_id
AND chr.sts_code ='BOOKED'
AND  hca.status = 'A'
AND chr.contract_number =NVL(p_contract_number,chr.contract_number)
AND chr.cust_acct_id = NVL(p_cust_acct_id,chr.cust_acct_id)
AND hca.account_number = NVL(p_cust_acct_number,hca.account_number)
AND  (hpp.effective_end_date >=SYSDATE OR hpp.effective_end_date IS NULL);

IF x_cust_info.count =0 THEN
Raise ex_missing_customer_details;

END IF;

l_err_message        :=null;
l_err_code  		 := 0;

EXCEPTION
WHEN ex_missing_customer_details THEN
l_err_message  :=l_err_message||'Customer details for mentioned contract not found.Please verify contract number.';
l_err_code     := 1;
DBMS_output.put_line(l_err_message);

WHEN OTHERS THEN
l_err_message  :=l_err_message||'Unexpected error occured while fetching Customer details.'||SQLERRM;
l_err_code     := 1;
DBMS_output.put_line(l_err_message);

END;             


BEGIN
DBMS_output.put_line('Getting customer address details');
FOR i IN party_data_cur LOOP 

SELECT 		 hl.ADDRESS1
            ,hl.ADDRESS2
            ,hl.address3
            ,hl.address4
            ,hl.city
            ,hl.postal_code
            ,hl.state
			,hl.country country_code
            ,(SELECT  ftt.territory_short_name FROM FND_TERRITORIES_TL ftt WHERE hl.country=ftt.territory_code AND ftt.LANGUAGE = USERENV ('lang')) country
            ,HCSUA.site_use_code
            ,HCSUA.primary_flag
            BULK COLLECT INTO x_address_loc
    FROM hz_cust_acct_sites_all hcasa
		,hz_party_sites hps
		,HZ_CUST_SITE_USES_ALL HCSUA
		,HZ_LOCATIONS HL
 WHERe   hcasa.party_site_id = hps.party_site_id
         AND hcasa.cust_acct_site_id=hcsua.cust_acct_site_id
         AND hps.location_id = hl.location_id
         AND hcsua.status ='A'
         AND hps.party_id =i.party_id;

END LOOP;		 

IF x_address_loc.count =0 THEN
Raise ex_missing_address_details;
END IF;


l_err_message     := null;
l_err_code        := 0;

EXCEPTION
WHEN ex_missing_address_details THEN 
l_err_message  :=l_err_message||'Address details for mentioned type/site use code not found.';
l_err_code     := 1;
DBMS_output.put_line(l_err_message);

WHEN OTHERS THEN
l_err_message  :=l_err_message||'Unexpected error occured while fetching Address details.'||SQLERRM;
l_err_code     := 1;
DBMS_output.put_line(l_err_message);
END;


BEGIN
DBMS_output.put_line('Getting alternate phone details');

/*FOR i IN party_data_cur LOOP 

DBMS_output.put_line('Getting alternate phone details for account :'||i.account_number);
 SELECT  distinct hcp.phone_line_type
         ,hcp.phone_area_code
         ,hcp.phone_country_code
         ,hcp.phone_number
         ,hcp.phone_extension
         ,hcp.contact_point_purpose
         ,hcp.primary_flag
 BULK COLLECT INTO x_alt_phone
FROM HZ_CONTACT_POINTS hcp
 WHERE    hcp.OWNER_TABLE_ID(+) in(i.party_id,i.party_site_id)
 AND     hcp.contact_point_type(+) IN ( 'PHONE') 
 AND      hcp.status ='A';
 
 END LOOP;*/
 
 SELECT distinct xtt.tlcm_addr_typ_nm phone_line_type
,xppa.tlcm_area_cd  phone_area_code
,xppa.tlcm_intl_call_cd phone_country_code
,xppa.tlcm_line_num phone_number 
,xppa.tlcm_extn_num phone_extension
,xtct.tlcm_cntxt_typ_nm  contact_point_purpose
,DECODE(xtct.tlcm_cntxt_typ_nm,'Primary','Y','N') primary_flag
 BULK COLLECT INTO x_alt_phone
FROM okc_k_headers_all_b chr
    ,hz_cust_accounts_all hca
    ,XXMOBL_BASE_EXTND_XREF_T xbe
    ,xxmobl_prty_tlcm_addr_all_t xppa
    ,XXMOBL_PRTY_CUST_XREF_T  xpcx
    ,XXMOBL_TLCM_ADDR_TYP_LKP_T xtt
    ,XXMOBL_TLCM_CNTXT_TYP_LKP_T xtct
	--,XXMOBL_PRTY_ALL_T  xpat
WHERE hca.cust_account_id= chr.cust_acct_id
AND  chr.contract_number = xbe.contract_number
AND  chr.cust_acct_id =xpcx.account_number
AND  to_char(xpcx.prty_id) =hca.orig_system_reference
AND xppa.prty_id 		   =xpcx.prty_id
AND xtt.tlcm_addr_typ_id =xppa.tlcm_addr_typ_id
AND xtct.tlcm_cntxt_typ_cd=xppa.tlcm_cntxt_typ_id
AND chr.contract_number =NVL(p_contract_number,chr.contract_number)
AND chr.cust_acct_id = NVL(p_cust_acct_id,chr.cust_acct_id)
AND hca.account_number = NVL(p_cust_acct_number,hca.account_number);

IF x_alt_phone.count =0 THEN
Raise no_alt_phone_found;
END iF;

l_err_message  :=null;
l_err_code     := 0;

EXCEPTION
WHEN no_alt_phone_found THEN
l_err_message  :=l_err_message||'Alternate phone details for mentioned Contract not found.';
l_err_code     := 1;
DBMS_output.put_line(l_err_message);

WHEN OTHERS THEN
l_err_message  :=l_err_message||'Unexpected error occured while fetching phone details.'||SQLERRM;
l_err_code     := 1;
DBMS_output.put_line(l_err_message);

END;

BEGIN

DBMS_output.put_line('Getting alternate email details');
FOR i IN party_data_cur LOOP 
 SELECT distinct  hcp.email_address
		,hcp.primary_flag
		,hcp.email_format
        ,hcp.contact_point_purpose
 BULK COLLECT INTO x_alt_emails
FROM HZ_CONTACT_POINTS hcp
 WHERE    hcp.OWNER_TABLE_ID(+) in(i.party_id,i.party_site_id)
 AND     hcp.contact_point_type(+) IN ( 'EMAIL')
 AND      hcp.status ='A' ;

END LOOP;

If x_alt_emails.count =0 THEN

Raise no_alt_email_found; 

END IF;

l_err_message  :=null;
l_err_code     := 0;

EXCEPTION
WHEN no_alt_email_found THEN
l_err_message  :=l_err_message||'Email Address details for mentioned Contract not found.';
l_err_code     := 1;
DBMS_output.put_line(l_err_message);

WHEN OTHERS THEN
l_err_message  :=l_err_message||'Unexpected error occured while fetching  Email Address details.'||SQLERRM;
l_err_code     := 1;
DBMS_output.put_line(l_err_message);

END;

/*ELSE ---party details not found
x_error_message  :='Party details for mentioned Contract '||p_contract_number||'not found.';
x_error_code     := 1;

END IF;*/

ELSE  --paramters combination incorrect
x_error_message  :='Combination of parameters entered is Invalid please enter correct parameters.';
x_error_code     := 1;
END IF;

ELSE ---paramters invalid
x_error_message := l_error_message;
x_error_code    := l_error_code;

END IF;
ELSE --no paramters entered
x_error_message  :='Please provide at least one Input Parameter:Contract Number,Customer Account Id or Customer Account Number.';
x_error_code     := 1;
DBMS_output.put_line(x_error_message);

END IF;

EXCEPTION
WHEN OTHERS THEN
x_error_message  :='Error occured while fetching customer details.'||SQLERRM;
x_error_code     := 1;
DBMS_output.put_line(x_error_message);

END main_cust_info;

END XXRCSS_CUSTOMER_PKG;
/