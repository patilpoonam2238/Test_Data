create or replace PACKAGE XXRCSS_CONT_SCHEDULE_PKG AS 

 PROCEDURE main_schedule_details
 ( 
  p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
   ,x_inv_pmt_rec_type  OUT nocopy XXRCSS_TYPES_PK.inv_main_pmt_tbl_type   
	,x_tax_percent_th       OUT nocopy NUMBER   
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
);
END XXRCSS_CONT_SCHEDULE_PKG;
/