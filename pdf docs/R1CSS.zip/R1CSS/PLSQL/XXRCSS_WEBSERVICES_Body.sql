CREATE OR REPLACE PACKAGE BODY XXRCSS_WEBSERVICES AS 
PROCEDURE main_cust_info
(p_contract_number     IN okc_k_headers_all_b.contract_number%TYPE
  ,p_cust_acct_id      IN okc_k_headers_all_b.cust_acct_id%TYPE
  ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_cust_info    	  OUT nocopy XXRCSS_TYPES_PK.cust_tbl_type
  ,x_address_loc      OUT nocopy XXRCSS_TYPES_PK.loc_tbl_type
  ,x_alt_emails       OUT nocopy XXRCSS_TYPES_PK.email_tbl_type
  ,x_alt_phone        OUT nocopy XXRCSS_TYPES_PK.phone_tbl_type    
  ,x_error_message          OUT nocopy VARCHAR2
  ,x_error_code  		      OUT nocopy NUMBER
)
IS
BEGIN
XXRCSS_CUSTOMER_PKG.main_cust_info(p_contract_number,p_cust_acct_id,p_cust_acct_number
,x_cust_info,x_address_loc,x_alt_emails,x_alt_phone,x_error_message,x_error_code);

END;


PROCEDURE main_asset_info
( p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_asset_info    	  OUT nocopy XXRCSS_TYPES_PK.asset_tbl_type    
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
)
IS
BEGIN
XXRCSS_ASSET_PKG.main_asset_info(p_cust_acct_number,x_asset_info,x_error_message,x_error_code);

END;


PROCEDURE main_contract_summary
 ( 
  p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
  ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_contract_info    	  OUT nocopy XXRCSS_TYPES_PK.contract_main_tbl_type
  ,x_latePolicyTblType  OUT nocopy  XXRCSS_TYPES_PK.latePolicyTblType 
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
)
IS
BEGIN
XXRCSS_CONTRACT_PKG.main_contract_summary(p_contract_number,p_cust_acct_number,x_contract_info,x_latePolicyTblType,x_error_message,x_error_code);
END;


PROCEDURE main_cont_transactions
 ( 
  p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
  ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_inv_pmt_rec_type    	  OUT nocopy XXRCSS_TYPES_PK.inv_main_pmt_tbl_type  
  ,x_onacct_rec_type   OUT nocopy XXRCSS_TYPES_PK.onacct_tbl_type  
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
)
IS
BEGIN
XXRCSS_CONT_TRANSACTIONS_PKG.main_cont_transactions(p_contract_number,p_cust_acct_number,x_inv_pmt_rec_type,x_onacct_rec_type,x_error_message,x_error_code);
END;

PROCEDURE main_schedule_details
 ( 
  p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
  ,x_inv_pmt_rec_type    	  OUT nocopy XXRCSS_TYPES_PK.inv_main_pmt_tbl_type  
,x_tax_percent_th       OUT nocopy NUMBER  
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
)
IS
BEGIN
XXRCSS_CONT_SCHEDULE_PKG.main_schedule_details(p_contract_number,x_inv_pmt_rec_type,x_tax_percent_th,x_error_message,x_error_code);
END;


 PROCEDURE main_test_data
 ( 
  p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
  ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_main_test_data OUT nocopy XXRCSS_TYPES_PK.mainTrxDataTblType   
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
)
IS
BEGIN
XXRCSS_TESTING_API_PKG.main_test_data(p_contract_number,p_cust_acct_number,x_main_test_data,x_error_message,x_error_code);
END;


PROCEDURE main_pmt_history
 ( 
  p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
  ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_inv_rcpt_rec_type    	  OUT nocopy XXRCSS_TYPES_PK.inv_main_rcpt_tbl_type   
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
)
IS
BEGIN
XXRCSS_CONT_RCV_TRANSACT_PKG.main_pmt_history(p_contract_number,p_cust_acct_number,x_inv_rcpt_rec_type,x_error_message,x_error_code);
END;


PROCEDURE main_bank_summary
 ( 
  p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
  ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_bank_hdr_main    	  OUT nocopy XXRCSS_TYPES_PK.contPdcTblType   
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
)
IS
BEGIN
XXRCSS_BANK_PKG.main_bank_summary(p_contract_number,p_cust_acct_number,x_bank_hdr_main,x_error_message,x_error_code);
END;

END XXRCSS_WEBSERVICES;
/