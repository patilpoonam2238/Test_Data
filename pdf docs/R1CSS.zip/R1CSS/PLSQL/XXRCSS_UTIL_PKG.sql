create or replace PACKAGE XXRCSS_UTIL_PKG AS 


FUNCTION get_party_details 
(p_contract_number IN okc_k_headers_all_b.contract_number%TYPE) RETURN NUMBER;

FUNCTION get_org_details 
(p_contract_number IN okc_k_headers_all_b.contract_number%TYPE) RETURN NUMBER;

PROCEDURE validate_contract(p_contract_number   IN okc_k_headers_all_b.contract_number%TYPE
						   ,p_cust_acct_id      IN okc_k_headers_all_b.cust_acct_id%TYPE
						   ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
						   ,l_contract_num     OUT NUMBER); 
						   
PROCEDURE validate_contract(p_contract_number   IN okc_k_headers_all_b.contract_number%TYPE
						   ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
						   ,l_contract_num     OUT NUMBER);
END XXRCSS_UTIL_PKG ;
/
