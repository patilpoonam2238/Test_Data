create or replace PACKAGE XXRCSS_BANK_PKG AS 

 PROCEDURE main_bank_summary
 ( 
    p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
   ,p_cust_acct_number IN hz_cust_accounts_all.account_number%TYPE
   ,x_bank_hdr_main    OUT nocopy XXRCSS_TYPES_PK.contPdcTblType   
   ,x_error_message    OUT nocopy VARCHAR2
   ,x_error_code       OUT nocopy NUMBER
);
END XXRCSS_BANK_PKG;
/