create or replace PACKAGE XXRCSS_TESTING_API_PKG AS 

 PROCEDURE main_test_data
 ( 
  p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
  ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_main_test_data OUT nocopy XXRCSS_TYPES_PK.mainTrxDataTblType 
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
);
END XXRCSS_TESTING_API_PKG;
/
