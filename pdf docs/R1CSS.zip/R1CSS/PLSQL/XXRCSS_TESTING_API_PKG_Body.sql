CREATE OR REPLACE PACKAGE BODY XXRCSS_TESTING_API_PKG AS

PROCEDURE main_test_data
 ( 
  p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
  ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_main_test_data  OUT nocopy XXRCSS_TYPES_PK.mainTrxDataTblType 
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
)
IS

ex_missing_contract_hdr EXCEPTION ;
ex_missing_contract_details EXCEPTION ;
ex_missing_policy_details EXCEPTION;
ex_missing_inspolicy_details EXCEPTION;

l_err_message VARCHAR2(4000);
l_err_code  NUMBER;

l_error_message VARCHAR2(4000):= null;
l_error_code  NUMBER :=0;

l_contract_num 		okc_k_headers_all_b.contract_number%TYPE;
l_contract_number  okc_k_headers_all_b.contract_number%TYPE;
l_cust_acct_number hz_cust_accounts_all.account_number%TYPe;
l_org_id             okc_k_headers_all_b.authoring_org_id%TYPE;

l_next_payment_amount NUMBER;
l_next_payment_date DATE;
l_billed_rcvbl   NUMBER;
										
l_account_count NUMBER :=0;

CURSOR contract_data(p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
					,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE) IS
 SELECT distinct
 chr.contract_number,chr.id,cust_acct_id
FROM okc_k_headers_all_b chr
	,hz_cust_accounts_all hca  	  
WHERE  chr.cust_acct_id =hca.cust_account_id 
AND hca.status ='A'
AND chr.sts_code ='BOOKED'
AND hca.account_number = NVL(p_cust_acct_number,hca.account_number)
AND chr.contract_number = NVL(p_contract_number,chr.contract_number);


CURSOR receipt_data(p_contract_id IN okc_k_headers_all_b.id%TYPE)
IS 
SELECT distinct RECEIPT_NUMBER,receipt_date
FROM okl_cs_cont_inv_receipts_uv
WHERE khr_id =p_contract_id
order by receipt_date;


BEGIN

DBMS_output.put_line('p_contract_number'||p_contract_number);
DBMS_output.put_line('p_cust_acct_number'||p_cust_acct_number);

IF (p_contract_number IS NOT NULL OR p_cust_acct_number IS NOT NULL) THEN 

dbms_output.put_line('Validate Parameters');


IF p_contract_number IS NOT NULL THEN 
BEGIN
dbms_output.put_line('Validate Contract Number');

SELECT chr.contract_number 
  INTO l_contract_number 
  FROM  okc_k_headers_all_b chr
  WHERE  chr.contract_number = p_contract_number
  AND   chr.sts_code ='BOOKED';

EXCEPTION
WHEN NO_DATA_FOUND THEN
l_error_message  :='Contract Number is Invalid or Contract not yet BOOKED.';
l_error_code     := 1;
DBMS_output.put_line(x_error_message);

WHEN OTHERS THEN
l_error_message  :='Error occured while validating contract number.'||SQLERRM;
l_error_code     := 1;
DBMS_output.put_line(x_error_message);
END;
END IF;


IF p_cust_acct_number IS NOT NULL THEN
BEGIN
dbms_output.put_line('Validate Customer Account Number');

SELECT account_number
INTO l_cust_acct_number
FROM hz_cust_accounts_all hca
WHERE hca.account_number =p_cust_acct_number
AND  hca.status = 'A';


IF l_cust_acct_number IS NOT NULL THEN 

SELECT count(*) 
  INTO l_account_count
  FROM  okc_k_headers_all_b chr
        ,hz_cust_accounts_all hca
  WHERE  chr.cust_acct_id =hca.cust_account_id
  AND   hca.account_number  = l_cust_acct_number
  AND   chr.sts_code ='BOOKED'
  AND   hca.status = 'A';

 IF   l_account_count = 0 THEN 
 l_error_message  :=l_error_message||'For entered Customer Account Number, Contract not available in BOOKED state.';
l_error_code     := 1;
DBMS_output.put_line(x_error_message);
 END IF;

END IF; 

EXCEPTION
WHEN NO_DATA_FOUND THEN
l_error_message  :=l_error_message||'Entered Customer Account Number is Invalid or Incorrect.';
l_error_code     := 1;
DBMS_output.put_line(x_error_message);

WHEN OTHERS THEN
l_error_message  :=l_error_message||'Error occured while validating Customer Account Number.'||SQLERRM;
l_error_code     := 1;
DBMS_output.put_line(x_error_message);
END;
END IF;

dbms_output.put_line('l_error_message '||l_error_message);
dbms_output.put_line('l_error_code '||l_error_code);
IF l_error_message IS NULL and l_error_code <> 1 THEN 

BEGIN
dbms_output.put_line('Calling Validate Contract Proc to verify combination of parameters');

 XXRCSS_UTIL_PKG.validate_contract(p_contract_number,p_cust_acct_number,l_contract_num);

dbms_output.put_line('Contract Number-'||l_contract_num);
EXCEPTION
WHEN OTHERS THEN
x_error_message  :='Error occured while validating contract number.'||SQLERRM;
x_error_code     := 1;
DBMS_output.put_line(x_error_message);
END;

IF l_contract_num IS NOT NULL THEN 

dbms_output.put_line('Get org details');

l_org_id :=XXRCSS_UTIL_PKG.get_org_details(l_contract_num);

MO_GLOBAL.set_policy_context('S',l_org_id);


BEGIN
DBMS_output.put_line('Getting Contract header details'); 
            
       x_main_test_data :=XXRCSS_TYPES_PK.mainTrxDataTblType();
				
            FOR i IN contract_data(p_contract_number,p_cust_acct_number) LOOP
                x_main_test_data.EXTEND;		
                DBMS_output.put_line(i.contract_number);
                x_main_test_data(x_main_test_data.LAST).xConTrxData := XXRCSS_TYPES_PK.contractTrxTblType();
                
                SELECT hdr.chr_contract_number
						 ,hdr.chr_start_date
						 ,hdr.chr_end_date
						 ,cust.statement_cycle_name
						 ,flv.meaning
					 BULK COLLECT INTO x_main_test_data(x_main_test_data.LAST).xContHdrData
					FROM  okl_k_hdrs_full_uv hdr
						 ,okl_cs_cust_acct_overview_uv cust
						  ,fnd_lookup_values flv
					WHERE chr_cust_acct_id =  cust.cust_account_id
					AND   hdr.khr_deal_type =flv.lookup_code
                    AND   flv.lookup_type ='OKL_BOOK_CLASS'
                    AND   flv.language =USERENV('LANG')
					AND hdr.chr_contract_number=i.contract_number;
					
					
          For j in receipt_data(i.id) LOOP
                  x_main_test_data(x_main_test_data.LAST).xConTrxData.EXTEND;
					
					SELECT distinct  recpt.receipt_number
						  ,recpt.receipt_date
						  ,recpt.receipt_amount
						  ,recpt.payment_method
						  ,recpt.onaccount_amount
						  ,null
						  ,null
					BULK COLLECT INTO  x_main_test_data(x_main_test_data.LAST).xConTrxData(x_main_test_data(x_main_test_data.LAST).xConTrxData.LAST).x_cont_receipt_tbl_type							  	  
					FROM okl_cs_cont_inv_receipts_uv recpt
					where recpt.receipt_number=j.receipt_number
					AND recpt.cust_account_id =i.cust_acct_id
                    AND recpt.khr_id =i.id;
					
					
					SELECT distinct inv.invoice_date						  
						  ,inv.invoice_amount
						  ,inv.amount_applied 	
						  ,btrx.transaction_type
						  ,btrx.amount_applied receipt_amt_applied
					BULK COLLECT INTO  x_main_test_data(x_main_test_data.LAST).xConTrxData(x_main_test_data(x_main_test_data.LAST).xConTrxData.LAST).x_contract_inv_hdr							  	  					  
					FROM okl_cs_cont_inv_receipts_uv recpt
						,okl_cs_account_inv_uv  inv
						,okl_cs_billingtrx_uv  btrx
					where  recpt.cust_account_id = inv.customer_acct_id
					AND recpt.invoice_number =inv.invoice_number
					AND recpt.cust_account_id = btrx.customer_account_id
					AND inv.invoice_number = btrx.invoice_number
					AND recpt.CUST_ACCOUNT_ID=i.cust_acct_id
					AND recpt.khr_id = i.id
					AND recpt.receipt_number = j.receipt_number
                    order by 1;
			END LOOP;	
	--	END LOOP; 
--------------------outstanding due-----------------------------------------------------	
			/*	SELECT inv.due_date						  
						  ,inv.amount_remaining
						  ,btrx.transaction_type
					BULK COLLECT INTO  x_main_test_data(x_main_test_data.LAST).xConOutstandingData							  	  					  
					FROM okl_cs_account_inv_uv  inv
						,okl_cs_billingtrx_uv  btrx
					where  btrx.customer_account_id = inv.customer_acct_id
					AND inv.invoice_number = btrx.invoice_number
					AND btrx.customer_account_id=i.cust_acct_id                    
                    AND (inv.invoice_date < SYSDATE AND inv.amount_remaining <> 0)
					AND btrx.khr_id = i.id;	*/
		 okl_cs_lc_contract_pvt.outstanding_billed_amt(p_contract_id  => i.id,
                                                      o_billed_amt   => l_billed_rcvbl);
          
          SELECT  l_billed_rcvbl
          BULK COLLECT INTO x_main_test_data(x_main_test_data.LAST).xConOutstandingData
          FROM dual;
    --   x_main_test_data.xConOutstandingData(1).x_amount_remaining:=l_billed_rcvbl;                                            
---------------------next installment due--------------------------------
									
			  okl_cs_lc_contract_pvt.next_due(p_contract_id => i.id,
                                        o_next_due_amt    => l_next_payment_amount,
                                        o_next_due_date   => l_next_payment_date);		
	
    SELECT l_next_payment_date,l_next_payment_amount
     BULK COLLECT INTO x_main_test_data(x_main_test_data.LAST).xConNextPmtData
    FROm dual;
--x_main_test_data.xConNextPmtData(1).x_due_date := l_next_payment_date;
--	x_main_test_data.xConNextPmtData(1).x_amount_remaining := l_next_payment_amount;
				
   
END LOOP;

IF x_main_test_data.count =0 THEN
Raise ex_missing_contract_details;
END iF;
l_err_message        :=null;
l_err_code  		 := 0;


EXCEPTION
WHEN ex_missing_contract_details THEN
l_err_message  :=l_err_message||'Contract details for mentioned contract not found.Please verify contract number.';
l_err_code     := 1;
DBMS_output.put_line(l_err_message);

WHEN OTHERS THEN
l_err_message  :=l_err_message||'Unexpected error occured while fetching Contract details.'||SQLERRM;
l_err_code     := 1;
DBMS_output.put_line(l_err_message);

END;             



ELSE  --paramters combination incorrect
x_error_message  :='Combination of parameters entered is Invalid please enter correct parameters.';
x_error_code     := 1;
END IF;

ELSE ---paramters invalid
x_error_message := l_error_message;
x_error_code    := l_error_code;

END IF;
ELSE --no paramters entered
x_error_message  :='Please provide at least one Input Parameter:Contract Number or Customer Account Number.';
x_error_code     := 1;
DBMS_output.put_line(x_error_message);

END IF;

EXCEPTION
WHEN OTHERS THEN
x_error_message  :='Error occured while fetching contract details.'||SQLERRM;
x_error_code     := 1;
DBMS_output.put_line(x_error_message);

END main_test_data;

END XXRCSS_TESTING_API_PKG;
/