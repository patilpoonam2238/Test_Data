CREATE OR REPLACE PACKAGE BODY XXRCSS_CONT_TRANSACTIONS_PKG AS

PROCEDURE main_cont_transactions
 ( 
  p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
  ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_inv_pmt_rec_type  OUT nocopy XXRCSS_TYPES_PK.inv_main_pmt_tbl_type 
  ,x_onacct_rec_type   OUT nocopy XXRCSS_TYPES_PK.onacct_tbl_type
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
)
IS

ex_missing_inv_details EXCEPTION ;

l_err_message VARCHAR2(4000);
l_err_code  NUMBER;

l_error_message VARCHAR2(4000):= null;
l_error_code  NUMBER :=0;
l_org_id             okc_k_headers_all_b.authoring_org_id%TYPE;

l_contract_num 		okc_k_headers_all_b.contract_number%TYPE;
l_contract_number  okc_k_headers_all_b.contract_number%TYPE;
l_cust_acct_number hz_cust_accounts_all.account_number%TYPe;

l_account_count NUMBER :=0;

CURSOR contract_data(p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
					,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE) IS
 SELECT distinct
 chr.contract_number
 ,chr.id 
FROM okc_k_headers_all_b chr
	,hz_cust_accounts_all hca  	  
WHERE  chr.cust_acct_id =hca.cust_account_id 
AND hca.status ='A'
AND chr.sts_code ='BOOKED'
AND hca.account_number = NVL(p_cust_acct_number,hca.account_number)
AND chr.contract_number = NVL(p_contract_number,chr.contract_number);

CURSOR invoice_data(p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE)
IS 
SELECT  
distinct cust_trx.trx_number invoice_number
from ra_customer_trx_all        cust_trx,
 ra_customer_trx_lines_all  cust_trx_line,
    ar_payment_schedules_all   pay_sch,
    okc_k_headers_all_b        chr,
     ar_receipt_methods         rm_lkup
 where interface_header_attribute6 =p_contract_number
and cust_trx.customer_trx_id = pay_sch.customer_trx_id
and cust_trx.customer_trx_id=cust_trx_line.customer_trx_id
and cust_trx_line.line_type='LINE'
and chr.contract_number = cust_trx.interface_header_attribute6
and  chr.cust_acct_id=cust_trx.bill_to_customer_id
and rm_lkup.receipt_method_id (+)= cust_trx.receipt_method_id
and cust_trx_line.interface_line_attribute9 not in ('DOWN PAYMENT','PASS THROUGH DLT FEE PAYMENT','STAMP DUTY PAYMENT','PASS THROUGH INSURANCE FEE PAYMENT','ADMINISTRATION FEE','INSURANCE FEE PAYMENT')
order by  cust_trx.trx_number desc;	
BEGIN

DBMS_output.put_line('p_contract_number'||p_contract_number);
DBMS_output.put_line('p_cust_acct_number'||p_cust_acct_number);

IF (p_contract_number IS NOT NULL OR p_cust_acct_number IS NOT NULL) THEN 

dbms_output.put_line('Validate Parameters');


IF p_contract_number IS NOT NULL THEN 
BEGIN
dbms_output.put_line('Validate Contract Number');

SELECT chr.contract_number 
  INTO l_contract_number 
  FROM  okc_k_headers_all_b chr
  WHERE  chr.contract_number = p_contract_number
  AND   chr.sts_code ='BOOKED';

EXCEPTION
WHEN NO_DATA_FOUND THEN
l_error_message  :='Contract Number is Invalid or Contract not yet BOOKED.';
l_error_code     := 1;
DBMS_output.put_line(x_error_message);

WHEN OTHERS THEN
l_error_message  :='Error occured while validating contract number.'||SQLERRM;
l_error_code     := 1;
DBMS_output.put_line(x_error_message);
END;
END IF;


IF p_cust_acct_number IS NOT NULL THEN
BEGIN
dbms_output.put_line('Validate Customer Account Number');

SELECT account_number
INTO l_cust_acct_number
FROM hz_cust_accounts_all hca
WHERE hca.account_number =p_cust_acct_number
AND  hca.status = 'A';


IF l_cust_acct_number IS NOT NULL THEN 

SELECT count(*) 
  INTO l_account_count
  FROM  okc_k_headers_all_b chr
        ,hz_cust_accounts_all hca
  WHERE  chr.cust_acct_id =hca.cust_account_id
  AND   hca.account_number  = l_cust_acct_number
  AND   chr.sts_code ='BOOKED'
  AND   hca.status = 'A';

 IF   l_account_count = 0 THEN 
 l_error_message  :=l_error_message||'For entered Customer Account Number, Contract not available in BOOKED state.';
l_error_code     := 1;
DBMS_output.put_line(x_error_message);
 END IF;

END IF; 

EXCEPTION
WHEN NO_DATA_FOUND THEN
l_error_message  :=l_error_message||'Entered Customer Account Number is Invalid or Incorrect.';
l_error_code     := 1;
DBMS_output.put_line(x_error_message);

WHEN OTHERS THEN
l_error_message  :=l_error_message||'Error occured while validating Customer Account Number.'||SQLERRM;
l_error_code     := 1;
DBMS_output.put_line(x_error_message);
END;
END IF;

dbms_output.put_line('l_error_message '||l_error_message);
dbms_output.put_line('l_error_code '||l_error_code);
IF l_error_message IS NULL and l_error_code <> 1 THEN 

BEGIN
dbms_output.put_line('Calling Validate Contract Proc to verify combination of parameters');

 XXRCSS_UTIL_PKG.validate_contract(p_contract_number,p_cust_acct_number,l_contract_num);

dbms_output.put_line('Contract Number-'||l_contract_num);
EXCEPTION
WHEN OTHERS THEN
x_error_message  :='Error occured while validating contract number.'||SQLERRM;
x_error_code     := 1;
DBMS_output.put_line(x_error_message);
END;

IF l_contract_num IS NOT NULL THEN 

dbms_output.put_line('Get org details');

l_org_id :=XXRCSS_UTIL_PKG.get_org_details(l_contract_num);

MO_GLOBAL.set_policy_context('S',l_org_id);

        BEGIN
            DBMS_output.put_line('Getting Contract invoice header details');
            x_inv_pmt_rec_type :=XXRCSS_TYPES_PK.inv_main_pmt_tbl_type();
            
            FOR i IN contract_data(p_contract_number,p_cust_acct_number) LOOP
                x_inv_pmt_rec_type.EXTEND;
                DBMS_output.put_line(i.contract_number);
                x_inv_pmt_rec_type(x_inv_pmt_rec_type.LAST).x_contract_inv := XXRCSS_TYPES_PK.contract_inv_tbl_type();               
                SELECT chr.contract_number
                INTO x_inv_pmt_rec_type(x_inv_pmt_rec_type.LAST).x_contract_num.x_contract_number
                FROM okc_k_headers_all_b chr
                    ,hz_cust_accounts_all hca  	  
                WHERE  chr.cust_acct_id =hca.cust_account_id 
                AND hca.status ='A'
                AND chr.sts_code ='BOOKED'
                AND chr.contract_number = i.contract_number;
                				
                
                FOR j in invoice_data(i.contract_number) LOOP
                
                    x_inv_pmt_rec_type(x_inv_pmt_rec_type.LAST).x_contract_inv.EXTEND;
                    DBMS_output.put_line('ANBCV' ||j.invoice_number);
                    SELECT  
                        distinct cust_trx.trx_number invoice_number
                        ,cust_trx.trx_date invoice_date 
                        ,pay_sch.amount_due_original invoice_amount
                        ,pay_sch.due_date invoice_due_date
                        ,pay_sch.amount_due_remaining
                        ,cust_trx.invoice_currency_code currency
                        ,pay_sch.amount_applied
                        ,pay_sch.amount_adjusted    
                        ,pay_sch.amount_credited
                        ,(SELECT  name FROM ra_terms  WHERE term_id = pay_sch.term_id ) payment_term
                    INTO  x_inv_pmt_rec_type(x_inv_pmt_rec_type.LAST).x_contract_inv(x_inv_pmt_rec_type(x_inv_pmt_rec_type.LAST).x_contract_inv.LAST).x_contract_inv_hdr
                    from    ra_customer_trx_all        cust_trx,
                            ra_customer_trx_lines_all  cust_trx_line,
                            ar_payment_schedules_all   pay_sch,
                            okc_k_headers_all_b        chr
                    where interface_header_attribute6 = i.contract_number
                    and cust_trx.customer_trx_id = pay_sch.customer_trx_id
                    and cust_trx.customer_trx_id=cust_trx_line.customer_trx_id
                    and cust_trx_line.line_type='LINE'
                    and chr.contract_number = cust_trx.interface_header_attribute6
					and  chr.cust_acct_id   = cust_trx.bill_to_customer_id
                    and cust_trx.trx_number = j.invoice_number
                    order by 2 desc;
                    
                  SELECT  distinct
                        cust_trx_line.interface_line_attribute9 payment_type
                        ,((cust_trx_line.line_recoverable)+NVL(cust_trx_line.tax_recoverable,0)) Amount
						,lat_pol.late_policy_exempt_yn
						,NVL(lat_pol.late_int_ass_yn,'N') late_int_ass_yn
                    BULK COLLECT INTO  x_inv_pmt_rec_type(x_inv_pmt_rec_type.LAST).x_contract_inv(x_inv_pmt_rec_type(x_inv_pmt_rec_type.LAST).x_contract_inv.LAST).x_contract_pmt_tbl_type
                    from    ra_customer_trx_all        cust_trx,
                            ra_customer_trx_lines_all  cust_trx_line,
                            ar_payment_schedules_all   pay_sch,
                            okc_k_headers_all_b        chr
				  ,(SELECT exempt.late_policy_exempt_yn
                          ,txd.khr_id
                          ,txd.id
                          ,txd.late_int_ass_yn
                             FROM  okl_txd_ar_ln_dtls_b 		TXD
                              ,okl_strm_type_exempt     exempt
                             ,OKL_LATE_POLICIES_V 		lte                            
                              ,okc_rules_b 				rul
                             where   TXD.KHR_ID = rul.dnz_chr_id 
                            ANd  TXD.sty_id = exempt.sty_id
                            AND lte.id = exempt.lpo_id
                            and (lte.late_policy_type_code(+) = 'LCT' or lte.late_policy_type_code(+) = 'INT')
                            and rul.rule_information_category(+) = 'LALCIN'
                            and  rul.rule_information1 = lte.id(+)) lat_pol
                    where interface_header_attribute6 = i.contract_number
                    and cust_trx.customer_trx_id = pay_sch.customer_trx_id
                    and cust_trx.customer_trx_id=cust_trx_line.customer_trx_id
                    and cust_trx_line.line_type='LINE'
                    and chr.contract_number = cust_trx.interface_header_attribute6
					and  chr.cust_acct_id=cust_trx.bill_to_customer_id
                     AND  lat_pol.KHR_ID = chr.id
                     AND  TO_CHAR(lat_pol.ID) = cust_trx_line.INTERFACE_LINE_ATTRIBUTE14
                    and cust_trx.trx_number = j.invoice_number
                    order by 2;
					
SELECT
receipt_number
,receipt_date
,receipt_amount
,sum(receipt_amt_applied)
,onaccount_amount
,receipt_method
,status
,reversal_desc
 BULK COLLECT INTO  x_inv_pmt_rec_type(x_inv_pmt_rec_type.LAST).x_contract_inv(x_inv_pmt_rec_type(x_inv_pmt_rec_type.LAST).x_contract_inv.LAST).x_cont_receipt_tbl_type                                     
FROM(SELECT distinct  
							acra.receipt_number
							,acra.receipt_date
							,acra.amount receipt_amount
							,aaa.amount_applied receipt_amt_applied --DECODE(acra.status,'APP',aaa.amount_applied) receipt_amt_applied
							,(SELECT nvl(SUM(acc_line.amount_applied), 0)
							  FROM ar_receivable_applications_all acc_line
							  WHERE acc_line.cash_receipt_id = acra.cash_receipt_id
							  AND acc_line.status = 'ACC'
							  AND acc_line.application_type = 'CASH'
							 ) onaccount_amount							 
							,rm_lkup.name receipt_method
							,DECODE(acra.status,'NSF','NSF','APP')  status
							,arlk.description  reversal_desc
						--	BULK COLLECT INTO  x_inv_pmt_rec_type(x_inv_pmt_rec_type.LAST).x_contract_inv(x_inv_pmt_rec_type(x_inv_pmt_rec_type.LAST).x_contract_inv.LAST).x_cont_receipt_tbl_type
							 FROM ra_customer_trx_all        cust_trx
							 ,ra_customer_trx_lines_all  cust_trx_line
								,ar_payment_schedules_all   pay_sch
								,okc_k_headers_all_b        chr
								 ,ar_receipt_methods         rm_lkup
								 ,ar_cash_receipts_all  acra
								 ,ar_receivable_applications_all aaa
								 ,ar_lookups arlk
							 where interface_header_attribute6 = i.contract_number
							 and  cust_trx.trx_number   =j.invoice_number
							and cust_trx.customer_trx_id = pay_sch.customer_trx_id
							and cust_trx.customer_trx_id=cust_trx_line.customer_trx_id
							and acra.cash_receipt_id =aaa.cash_receipt_id
							and aaa.applied_customer_trx_id(+) =cust_trx.customer_trx_id
							and cust_trx_line.line_type='LINE'
							and chr.contract_number = cust_trx.interface_header_attribute6
							and rm_lkup.receipt_method_id(+) = acra.receipt_method_id
							and arlk.lookup_code(+) = acra.reversal_reason_code
                            and arlk.lookup_type(+)  ='XXJDF_REVERSAL_REASON'   -- need to be updated'CKAJST_REASON'
							and aaa.status ='APP'
							and aaa.display = DECODE(acra.status,'NSF','N','Y')             --added to fix -not to display credited invoices having receipt amt 0.
							and acra.status in('NSF','APP','UNAPP')
							AND EXISTS (
										SELECT
											1
										FROM
											ar_distributions_all ad
										WHERE
											ad.source_table = 'RA'
											AND ( ad.ref_customer_trx_line_id IS NULL
												  OR ad.ref_customer_trx_line_id = cust_trx_line.customer_trx_line_id )
											AND ad.source_id = aaa.receivable_application_id
									  )
									  )
group by receipt_number
,receipt_date
,receipt_amount
,onaccount_amount
,receipt_method
,status
,reversal_desc;
                    
                END LOOP;
            END LOOP;    
       
IF x_inv_pmt_rec_type.count =0 THEN
Raise ex_missing_inv_details;
END iF;
l_err_message        :=null;
l_err_code  		 := 0;

EXCEPTION
WHEN ex_missing_inv_details THEN
l_err_message  :=l_err_message||'Invoice details for mentioned contract not found.Please verify contract number.';
l_err_code     := 1;
DBMS_output.put_line(l_err_message);

WHEN OTHERS THEN
l_err_message  :=l_err_message||'Unexpected error occured while fetching invoice details.'||SQLERRM;
l_err_code     := 1;
DBMS_output.put_line(l_err_message);

END;             

/*on account receipt details*/
BEGIN
DBMS_output.put_line('Get onaccount receipt details');

  SELECT  distinct 
arcash.receipt_number  
 ,arcash.receipt_date
 ,sum(acc_line.amount_applied)onaccount_amount
 ,rm_lkup.name receipt_method
 BULK COLLECT INTO x_onacct_rec_type
 FROM ar_receivable_applications_all acc_line
      ,ar_cash_receipts_all arcash
      ,hz_cust_accounts_all hca
	  ,ar_receipt_methods         rm_lkup
  WHERE acc_line.cash_receipt_id = arcash.cash_receipt_id
  AND arcash.pay_from_customer =hca.cust_account_id
   AND acc_line.status = 'ACC'
   AND hca.account_number = p_cust_acct_number
   AND arcash.customer_receipt_reference is  null
   AND acc_line.application_type = 'CASH'
   AND rm_lkup.receipt_method_id(+) = arcash.receipt_method_id
    HAVING sum(acc_line.amount_applied) <> 0
   group by arcash.receipt_number
 ,arcash.receipt_date,rm_lkup.name;

EXCEPTION
WHEN OTHERS THEN
l_err_message  :=l_err_message||'Unexpected error occured while fetching onaccount receipt details.'||SQLERRM;
l_err_code     := 1;
DBMS_output.put_line(l_err_message);
END;



ELSE  --paramters combination incorrect
x_error_message  :='Combination of parameters entered is Invalid please enter correct parameters.';
x_error_code     := 1;
END IF;

ELSE ---paramters invalid
x_error_message := l_error_message;
x_error_code    := l_error_code;

END IF;
ELSE --no paramters entered
x_error_message  :='Please provide at least one Input Parameter:Contract Number or Customer Account Number.';
x_error_code     := 1;
DBMS_output.put_line(x_error_message);

END IF;

EXCEPTION
WHEN OTHERS THEN
x_error_message  :='Error occured while fetching invoice details.'||SQLERRM;
x_error_code     := 1;
DBMS_output.put_line(x_error_message);

END main_cont_transactions;

END XXRCSS_CONT_TRANSACTIONS_PKG;
/