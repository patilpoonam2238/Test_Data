create or replace PACKAGE BODY XXRCSS_CONTRACT_PKG AS

PROCEDURE main_contract_summary
 (
  p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
  ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
  ,x_contract_hdr_main  OUT nocopy XXRCSS_TYPES_PK.contract_main_tbl_type
  ,x_latePolicyTblType  OUT nocopy  XXRCSS_TYPES_PK.latePolicyTblType
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
)
IS

ex_missing_contract_hdr EXCEPTION ;
ex_missing_contract_details EXCEPTION ;
ex_missing_policy_details EXCEPTION;

l_err_message VARCHAR2(4000);
l_err_code  NUMBER;

l_error_message VARCHAR2(4000):= null;
l_error_code  NUMBER :=0;

l_contract_num 		okc_k_headers_all_b.contract_number%TYPE;
l_contract_number  okc_k_headers_all_b.contract_number%TYPE;
l_cust_acct_number hz_cust_accounts_all.account_number%TYPe;
l_org_id             okc_k_headers_all_b.authoring_org_id%TYPE;

l_account_count NUMBER :=0;

CURSOR contract_data(p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
					,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE) IS
 SELECT distinct
 chr.contract_number
FROM okc_k_headers_all_b chr
	,hz_cust_accounts_all hca
WHERE  chr.cust_acct_id =hca.cust_account_id
AND hca.status ='A'
AND chr.sts_code ='BOOKED'
AND hca.account_number = NVL(p_cust_acct_number,hca.account_number)
AND chr.contract_number = NVL(p_contract_number,chr.contract_number);

BEGIN

DBMS_output.put_line('p_contract_number'||p_contract_number);
DBMS_output.put_line('p_cust_acct_number'||p_cust_acct_number);

IF (p_contract_number IS NOT NULL OR p_cust_acct_number IS NOT NULL) THEN

dbms_output.put_line('Validate Parameters');


IF p_contract_number IS NOT NULL THEN
BEGIN
dbms_output.put_line('Validate Contract Number');

SELECT chr.contract_number
  INTO l_contract_number
  FROM  okc_k_headers_all_b chr
  WHERE  chr.contract_number = p_contract_number
  AND   chr.sts_code ='BOOKED';

EXCEPTION
WHEN NO_DATA_FOUND THEN
l_error_message  :='Contract Number is Invalid or Contract not yet BOOKED.';
l_error_code     := 1;
DBMS_output.put_line(x_error_message);

WHEN OTHERS THEN
l_error_message  :='Error occured while validating contract number.'||SQLERRM;
l_error_code     := 1;
DBMS_output.put_line(x_error_message);
END;
END IF;


IF p_cust_acct_number IS NOT NULL THEN
BEGIN
dbms_output.put_line('Validate Customer Account Number');

SELECT account_number
INTO l_cust_acct_number
FROM hz_cust_accounts_all hca
WHERE hca.account_number =p_cust_acct_number
AND  hca.status = 'A';


IF l_cust_acct_number IS NOT NULL THEN

SELECT count(*)
  INTO l_account_count
  FROM  okc_k_headers_all_b chr
        ,hz_cust_accounts_all hca
  WHERE  chr.cust_acct_id =hca.cust_account_id
  AND   hca.account_number  = l_cust_acct_number
  AND   chr.sts_code ='BOOKED'
  AND   hca.status = 'A';

 IF   l_account_count = 0 THEN
 l_error_message  :=l_error_message||'For entered Customer Account Number, Contract not available in BOOKED state.';
l_error_code     := 1;
DBMS_output.put_line(x_error_message);
 END IF;

END IF;

EXCEPTION
WHEN NO_DATA_FOUND THEN
l_error_message  :=l_error_message||'Entered Customer Account Number is Invalid or Incorrect.';
l_error_code     := 1;
DBMS_output.put_line(x_error_message);

WHEN OTHERS THEN
l_error_message  :=l_error_message||'Error occured while validating Customer Account Number.'||SQLERRM;
l_error_code     := 1;
DBMS_output.put_line(x_error_message);
END;
END IF;

dbms_output.put_line('l_error_message '||l_error_message);
dbms_output.put_line('l_error_code '||l_error_code);
IF l_error_message IS NULL and l_error_code <> 1 THEN

BEGIN
dbms_output.put_line('Calling Validate Contract Proc to verify combination of parameters');

 XXRCSS_UTIL_PKG.validate_contract(p_contract_number,p_cust_acct_number,l_contract_num);

dbms_output.put_line('Contract Number-'||l_contract_num);
EXCEPTION
WHEN OTHERS THEN
x_error_message  :='Error occured while validating contract number.'||SQLERRM;
x_error_code     := 1;
DBMS_output.put_line(x_error_message);
END;

IF l_contract_num IS NOT NULL THEN

dbms_output.put_line('Get org details');
l_org_id :=XXRCSS_UTIL_PKG.get_org_details(l_contract_num);

MO_GLOBAL.set_policy_context('S',l_org_id);

x_contract_hdr_main :=XXRCSS_TYPES_PK.contract_main_tbl_type();
BEGIN
DBMS_output.put_line('Getting Contract header details');

FOR i IN contract_data(p_contract_number,p_cust_acct_number) LOOP
x_contract_hdr_main.EXTEND;
  SELECT distinct
 chr.contract_number
 ,(select short_description from okc_k_headers_tl where id = chr.id and language =USERENV('LANG'))description
 ,chr.start_date loan_start_date
 ,chr.end_date loan_end_date
 ,khr.term_duration contract_tenure 
 ,(SELECT SUM(tl.amount)
      FROM okl_trx_ap_invoices_b th,
           okl_txl_ap_inv_lns_all_b tl
     WHERE th.id = tl.tap_id
       AND tl.khr_id = chr.id
       AND th.funding_type_code IN( 'ASSET','EXPENSE')
       AND th.trx_status_code ='PROCESSED' ) contract_financed_amount
 ,(select distinct arm.name
                    from RA_CUST_RECEIPT_METHODS rcr
                       , AR_RECEIPT_METHODS  arm
                    where customer_id =chr.cust_acct_id
                    AND  rcr.receipt_method_id=arm.receipt_method_id
                    AND  rcr.primary_flag ='Y') payment_method
      ,(select attribute2 from okl_k_headers okh where okh.id =chr.id) contract_interest_rate
      ,pdt.name product
      ,flv.meaning book_classfication
	  , (SELECT distinct okl_lla_util_pvt.get_lookup_meaning('OKL_FREQUENCY',rul.object1_id1) frequency
      FROM okc_rules_b rul,
        okc_rule_groups_b rgp,
        okc_rules_b rul_laslh,
        okl_strm_type_b styt
      WHERE rul.rgp_id                        = rgp.id
      AND rgp.rgd_code                        = 'LALEVL'
      AND rul.rule_information_category       = 'LASLL'
      AND rgp.dnz_chr_id                      = chr.id
      AND rul.jtot_object2_code               = 'OKL_STRMHDR'
      AND rul.dnz_chr_id                      = rgp.dnz_chr_id
      AND rul_laslh.rgp_id                    = rgp.id
      AND rul_laslh.dnz_chr_id                = rgp.dnz_chr_id
      AND rul_laslh.rule_information_category = 'LASLH'
      AND rul_laslh.jtot_object1_code         = 'OKL_STRMTYP'
	  AND rul.object2_id1               	  = rul_laslh.id
      AND styt.id                             = rul_laslh.object1_id1
      AND styt.code                           = 'RENT') payment_frequency
	  ,( SELECT distinct lpot.name	  
		FROM okl_late_policies_b    lte
             ,okl_late_policies_tl   lpot                             
             ,okc_rules_b rul
        WHERE  lte.id = lpot.id 
          and rul.rule_information_category(+) = 'LALCIN'
          and  rul.dnz_chr_id =chr.id
          and rul.rule_information1 = lte.id(+)
		  and  (lte.late_policy_type_code(+) = 'LCT' or lte.late_policy_type_code(+) = 'INT')
          AND lpot.language = userenv('LANG')
		 ) late_policy_name
 INTO x_contract_hdr_main(x_contract_hdr_main.LAST).x_contract_hdr_dtl
FROM okc_k_headers_all_b chr
	,hz_cust_accounts_all hca
    ,okl_k_headers khr
    ,okl_products pdt
    ,fnd_lookup_values flv
WHERE chr.cust_acct_id =hca.cust_account_id
AND   chr.id = khr.id
AND   khr.pdt_id = pdt.id
AND   khr.deal_type =flv.lookup_code
AND   flv.lookup_type ='OKL_BOOK_CLASS'
AND   flv.language =USERENV('LANG')
AND   hca.status ='A'
AND chr.sts_code ='BOOKED'
AND chr.contract_number = i.contract_number;


  SELECT distinct okl_deal_payments_pvt.get_asset_number(rgp.dnz_chr_id,rgp.cle_id,cle.lse_id) asset_number
         ,okl_lla_util_pvt.get_lookup_meaning('OKL_FREQUENCY',rul.object1_id1) payment_frequency
		 BULK COLLECT INTO x_contract_hdr_main(x_contract_hdr_main.LAST).x_contract_asset_dtl
      FROM okc_k_headers_all_b chr
      , okc_rules_b rul,
        okc_rule_groups_b rgp,
        okc_rules_b rul_laslh,
        okl_strm_type_b styt
        ,okc_k_lines_b cle
      WHERE rul.rgp_id                        = rgp.id
      AND chr.id                              = rgp.dnz_chr_id
      AND rgp.rgd_code                        = 'LALEVL'
      AND rul.rule_information_category       = 'LASLL'
      AND chr.contract_number                 = i.contract_number
      AND rul.jtot_object2_code               = 'OKL_STRMHDR'
      AND rul.dnz_chr_id                      = rgp.dnz_chr_id
      AND rul_laslh.rgp_id                    = rgp.id
      AND rul_laslh.dnz_chr_id                = rgp.dnz_chr_id
      AND rul_laslh.rule_information_category = 'LASLH'
      AND rul_laslh.jtot_object1_code         = 'OKL_STRMTYP'
	  AND rul.object2_id1                     = rul_laslh.id
      AND styt.id                             = rul_laslh.object1_id1
      AND cle.id (+)						  = rgp.cle_id
	  AND cle.dnz_chr_id 					  = rgp.dnz_chr_id
      AND styt.code                           = 'RENT';


END LOOP;


IF x_contract_hdr_main.count =0 THEN
Raise ex_missing_contract_details;
END iF;
l_err_message        :=null;
l_err_code  		 := 0;


EXCEPTION
WHEN ex_missing_contract_details THEN
l_err_message  :=l_err_message||'Contract details for mentioned contract not found.Please verify contract number.';
l_err_code     := 1;
DBMS_output.put_line(l_err_message);

WHEN OTHERS THEN
l_err_message  :=l_err_message||'Unexpected error occured while fetching Contract details.'||SQLERRM;
l_err_code     := 1;
DBMS_output.put_line(l_err_message);

END;


BEGIN


dbms_output.put_line('Get policy details org -'||l_org_id);

					SELECT  distinct lpot.name
						  , lte.late_policy_type_code
						  , lte.late_int_allowed_yn
						  , lte.late_int_fixed_yn
                          , nvl(lte.late_int_rate,0) late_int_rate
                          , nvl(lte.adder_rate,0) adder_rate
                          , nvl(lte.late_int_grace_period,0) late_int_grace_period
                          , nvl(lte.late_int_minimum_balance,0) late_int_minimum_balance
                          , nvl(lte.minimum_late_interest,0) minimum_late_interest
                          , nvl(lte.maximum_late_interest,9999999999) maximum_late_interest
                          , nvl(idx.value,0) index_rate
                          , nvl(lte.days_in_year, 'actual') days_in_year
						  , bill_min_interest_yn  bill_min_interest_yn
						  , idx.datetime_valid
						  , idx.datetime_invalid
					BULK COLLECT INTO x_latePolicyTblType
                    FROM   OKL_INDEX_VALUES IDX
						   ,okl_late_policies_b    LTE
                           ,okl_late_policies_tl   lpot
                  WHERE   LTE.id = lpot.id
                    and LTE.IDX_ID = IDX.IDX_ID(+)
					and LTE.org_id = l_org_id
                    AND lpot.language = userenv('LANG')
                    and  (lte.late_policy_type_code = 'LCT' or lte.late_policy_type_code = 'INT');


IF x_latePolicyTblType.count =0 THEN
Raise ex_missing_policy_details;
END iF;
l_err_message        :=null;
l_err_code  		 := 0;

EXCEPTION
WHEN ex_missing_policy_details THEN
l_err_message  :=l_err_message||'Policy details not found.';
l_err_code     := 1;
DBMS_output.put_line(l_err_message);

WHEN OTHERS THEN
l_err_message  :=l_err_message||'Unexpected error occured while fetching late policy details.'||SQLERRM;
l_err_code     := 1;
DBMS_output.put_line(l_err_message);
END;

ELSE  --paramters combination incorrect
x_error_message  :='Combination of parameters entered is Invalid please enter correct parameters.';
x_error_code     := 1;
END IF;

ELSE ---paramters invalid
x_error_message := l_error_message;
x_error_code    := l_error_code;

END IF;
ELSE --no paramters entered
x_error_message  :='Please provide at least one Input Parameter:Contract Number or Customer Account Number.';
x_error_code     := 1;
DBMS_output.put_line(x_error_message);

END IF;

EXCEPTION
WHEN OTHERS THEN
x_error_message  :='Error occured while fetching contract details.'||SQLERRM;
x_error_code     := 1;
DBMS_output.put_line(x_error_message);

END main_contract_summary;

END XXRCSS_CONTRACT_PKG;
/