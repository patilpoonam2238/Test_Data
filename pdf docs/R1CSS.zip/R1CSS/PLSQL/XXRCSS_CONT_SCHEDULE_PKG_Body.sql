CREATE OR REPLACE PACKAGE BODY XXRCSS_CONT_SCHEDULE_PKG AS

PROCEDURE main_schedule_details
 ( 
  p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
  ,x_inv_pmt_rec_type  OUT nocopy XXRCSS_TYPES_PK.inv_main_pmt_tbl_type    
  ,x_tax_percent_th       OUT nocopy NUMBER
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
)
IS

ex_missing_sch_details EXCEPTION ;

l_err_message VARCHAR2(4000);
l_err_code  NUMBER;

l_error_message VARCHAR2(4000):= null;
l_error_code  NUMBER :=0;


l_contract_num 		okc_k_headers_all_b.contract_number%TYPE;
l_contract_number  okc_k_headers_all_b.contract_number%TYPE;
l_cust_acct_number hz_cust_accounts_all.account_number%TYPe;
l_org_id             okc_k_headers_all_b.authoring_org_id%TYPE;

l_account_count NUMBER :=0;


BEGIN

DBMS_output.put_line('p_contract_number'||p_contract_number);


IF p_contract_number IS NOT NULL THEN 
BEGIN
dbms_output.put_line('Validate Contract Number');

SELECT chr.contract_number 
  INTO l_contract_number 
  FROM  okc_k_headers_all_b chr
  WHERE  chr.contract_number = p_contract_number
  AND   chr.sts_code ='BOOKED';

EXCEPTION
WHEN NO_DATA_FOUND THEN
l_error_message  :='Contract Number is Invalid or Contract not yet BOOKED.';
l_error_code     := 1;
DBMS_output.put_line(x_error_message);

WHEN OTHERS THEN
l_error_message  :='Error occured while validating contract number.'||SQLERRM;
l_error_code     := 1;
DBMS_output.put_line(x_error_message);
END;


dbms_output.put_line('l_error_message '||l_error_message);
dbms_output.put_line('l_error_code '||l_error_code);
IF l_error_message IS NULL and l_error_code <> 1 THEN 

x_inv_pmt_rec_type :=XXRCSS_TYPES_PK.inv_main_pmt_tbl_type();
 BEGIN
 x_inv_pmt_rec_type.EXTEND;
       DBMS_output.put_line('Getting Contract payment schedule details');
                DBMS_output.put_line(p_contract_number);
                x_inv_pmt_rec_type(x_inv_pmt_rec_type.LAST).x_contract_inv := XXRCSS_TYPES_PK.contract_inv_tbl_type();
                
                SELECT chr.contract_number
                INTO x_inv_pmt_rec_type(x_inv_pmt_rec_type.LAST).x_contract_num.x_contract_number
                FROM okc_k_headers_all_b chr
                    ,hz_cust_accounts_all hca  	  
                WHERE  chr.cust_acct_id =hca.cust_account_id 
                AND hca.status ='A'
                AND chr.sts_code ='BOOKED'
                AND chr.contract_number = p_contract_number;
                				
							 
			SELECT  sty.stream_type_purpose stream    ---removed distinct for multiple assets
						, (ste.amount) Installment_amount
						,ste.stream_element_date installment_billing_date
						,ste.date_billed  billed_date
						,cust_tbl.extended_amount invoice_amount
						,cust_tbl.amount_due_remaining
			  BULK COLLECT INTO x_inv_pmt_rec_type(x_inv_pmt_rec_type.LAST).x_pmt_schedule
			FROM okl_strm_elements ste
				 ,okl_streams stm
				 ,okl_strm_type_b sty
				,okc_k_headers_all_b        chr
				 , okc_k_lines_tl oklt
          ,okc_k_lines_b cle
				,(select  
						cust_trx.trx_date
						,sum(cust_trx_line.extended_amount) extended_amount
						,NVL(sum(cust_trx_line.amount_due_remaining),0) amount_due_remaining
						,cust_trx.interface_header_attribute6 
						, cust_trx_line.interface_line_attribute9
						,cust_trx_line.interface_line_attribute7
					from    ra_customer_trx_all        cust_trx,
							ra_customer_trx_lines_all  cust_trx_line
							where cust_trx.customer_trx_id=cust_trx_line.customer_trx_id
							and  cust_trx_line.interface_line_attribute9 in('RENT','INTEREST PAYMENT','PRINCIPAL PAYMENT','DOWN PAYMENT')
							and cust_trx_line.line_type='LINE'
							  group by cust_trx.TRX_DATE,  cust_trx.interface_header_attribute6 
						, cust_trx_line.interface_line_attribute9,cust_trx_line.interface_line_attribute7
					)cust_tbl                
			WHERE stm.sty_id               = sty.id
			  AND stm.say_code             = 'CURR'
			  AND stm.active_yn            = 'Y'
			  AND sty.stream_type_purpose IN ('RENT','INTEREST_PAYMENT','PRINCIPAL_PAYMENT','DOWN_PAYMENT')
			  AND stm.purpose_code        IS NULL
			  AND stm.id = ste.stm_id
			  AND ste.amount <> 0                       -- addded condition to exclude stub days. US96333 by ppatil
			  AND  chr.contract_number = p_contract_number
			  AND  chr.id 		= stm.khr_id
			  AND  oklt.id 		= cle.id 
              AND  cle. chr_id	= chr.id
              AND  cle.lse_id 	= 33
              AND  stm.kle_id	= cle.id
			  AND chr.contract_number = cust_tbl.interface_header_attribute6(+)
			  AND ste.stream_element_date =cust_tbl.trx_date(+)
			  AND sty.code = cust_tbl.interface_line_attribute9(+)
			--  AND  ste.amount = cust_tbl.unit_selling_price(+)
			 AND oklt.language =userenv('lang')
			 AND oklt.name =cust_tbl.interface_line_attribute7(+)
			order by 3 ;
   
       
IF x_inv_pmt_rec_type.count =0 THEN
Raise ex_missing_sch_details;
END iF;
l_err_message        :=null;
l_err_code  		 := 0;

EXCEPTION
WHEN ex_missing_sch_details THEN
l_err_message  :=l_err_message||'Schedule details for mentioned contract not found.Please verify contract number.';
l_err_code     := 1;
DBMS_output.put_line(l_err_message);

WHEN OTHERS THEN
l_err_message  :=l_err_message||'Unexpected error occured while fetching schedule details.'||SQLERRM;
l_err_code     := 1;
DBMS_output.put_line(l_err_message);

END; 

BEGIN  
dbms_output.put_line('Get org details');
l_org_id :=XXRCSS_UTIL_PKG.get_org_details(p_contract_number);          
dbms_output.put_line('Get Tax percentage for Thiland');

    
/*SELECT distinct zxr.percentage_rate
    INTO  x_tax_percent_th
    FROM zx_party_tax_profile ptp,
         zx_subscription_details zsd,
         hr_operating_units hou,
         zx_regimes_usages zru,
         zx_rates_vl zxr
   WHERE zxr.tax_regime_code         = zru.tax_regime_code
     AND ptp.party_id                = hou.organization_id
     AND zru.first_pty_org_id        = ptp.party_tax_profile_id
     AND zru.first_pty_org_id        = zsd.first_pty_org_id
     AND zsd.tax_regime_code         = zru.tax_regime_code
     AND hou.organization_id         = l_org_id
		AND zxr.tax_rate_code           = 'PAYABLE ON HP'
     AND zxr.active_flag             = 'Y'
     AND sysdate BETWEEN zxr.effective_from AND NVL(zxr.effective_to,sysdate)
     AND sysdate BETWEEN zsd.effective_from AND NVL(zsd.effective_to,sysdate);	*/
/*Get tax percentage for Thailand based on Stream type*/	

 SELECT distinct zxr.percentage_rate
   INTO  x_tax_percent_th
   FROM okc_k_headers_all_b chr
    ,okl_k_headers khr
    ,fnd_lookup_values flv
    ,okl_tax_attr_definitions  sttxtrxbizctgeo
    ,okl_strm_type_v   strm
    ,zx_conditions zcg
    ,zx_process_results zpr
    ,zx_rates_b zxr
WHERE  chr.id = khr.id
AND   khr.deal_type =flv.lookup_code
AND   flv.lookup_type ='OKL_BOOK_CLASS'
AND   flv.language =USERENV('LANG')
AND chr.sts_code ='BOOKED'
AND chr.contract_number = p_contract_number
AND sttxtrxbizctgeo.sty_id = strm.id (+)
AND sttxtrxbizctgeo.book_class_code = flv.lookup_code
AND zcg.condition_group_code        = zpr.condition_group_code
AND sttxtrxbizctgeo.result_code     = zcg.alphanumeric_value
AND zxr.tax_rate_code               = zpr.rate_result
AND zxr.active_flag                 = 'Y'
AND sysdate BETWEEN zxr.effective_from AND NVL(zxr.effective_to,sysdate)
AND strm.name ='RENT';	

EXCEPTION
WHEN OTHERS THEN 
l_err_message  :=l_err_message||'Unexpected error occured while fetching tax percentage details.'||SQLERRM;
l_err_code     := 1;
DBMS_output.put_line(l_err_message);

END;
ELSE ---paramters invalid
x_error_message := l_error_message;
x_error_code    := l_error_code;

END IF;

ELSE --no paramters entered
x_error_message  :='Please provide Input Parameter:Contract Number.';
x_error_code     := 1;
DBMS_output.put_line(x_error_message);

END IF;

EXCEPTION
WHEN OTHERS THEN
x_error_message  :='Error occured while fetching invoice details.'||SQLERRM;
x_error_code     := 1;
DBMS_output.put_line(x_error_message);

END main_schedule_details;

END XXRCSS_CONT_SCHEDULE_PKG;
/