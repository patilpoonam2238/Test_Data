create or replace PACKAGE XXRCSS_CONTRACT_PKG AS 

 PROCEDURE main_contract_summary
 ( 
  p_contract_number  IN okc_k_headers_all_b.contract_number%TYPE
  ,p_cust_acct_number  IN hz_cust_accounts_all.account_number%TYPE
   ,x_contract_hdr_main OUT nocopy XXRCSS_TYPES_PK.contract_main_tbl_type  
   ,x_latePolicyTblType  OUT nocopy  XXRCSS_TYPES_PK.latePolicyTblType   
  ,x_error_message    OUT nocopy VARCHAR2
  ,x_error_code       OUT nocopy NUMBER
);
END XXRCSS_CONTRACT_PKG;
/